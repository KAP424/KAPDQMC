# uniform A：时间尺度复核与 β 加密扫描

**原来统一使用 θ=2…6 的主拟合，没有充分建立小 θ 修正已受控；直接把 θ 向后增加，也会引入有限尺寸影响。因此旧主窗只能作为有限窗口诊断，不能当成已经确认的渐近角系数。** 全部 12 个构型、4 个 β 的独立复核见 [时间尺度审计](analysis_time_scale/FINDINGS.md)。

新增扫描、重新拟合及独立核验已完成。下面先给出 β 曲线和系数表，再说明时间窗限制与参考 notebook 的关系。

<!-- GENERATED_RESULTS_START -->
## 本轮完成的结果

β=0、0.1、…、2.0 的 **21 个点已完成**。本轮记录 698 个参数点，其中 336 个平衡点、362 个有限时间点；626 点新计算、72 点按原始值复用。所要求的网格完整，原始数据与独立高精度拟合核验均通过。

主平衡系数使用 L=18…144 的对数加逆尺寸修正；主非平衡系数使用 L=180、θ=4、4.5、…、7 的四参数模型，并在 L=144 的同时间网格上检查尺寸变化。每个 β 另检查 L=180 的 5…8 移窗，以及不同修正阶数。

两端主估计的相对差最大为 **1.98%**。3/21 个 β（0、0.1、0.2）通过本页列明的局部诊断；这仍是有限数据检查，不是渐近相等的定理。图中空心非平衡方块表示本页必需的局部检查未通过或缺失，其值只作诊断；实心非平衡方块也不代表已有第三尺寸验证。

平衡结果使用较粗的蓝色实线和大空心圆，非平衡结果使用橙色虚线和较小方块。重叠时仍可见虚线间的蓝线及方块外的圆环；数据坐标没有偏移。蓝色空心圆只表示平衡数据，不表示未通过局部检查。

![uniform A 的平衡与非平衡角贡献系数随 β 变化](figures_uniformA_dense/corner_coefficient_beta.png)

[PNG](figures_uniformA_dense/corner_coefficient_beta.png) · [PDF](figures_uniformA_dense/corner_coefficient_beta.pdf)

下图补充系数比值和相对差，避免在强测量的小信号区只看线性纵轴就误以为两条曲线完全重合。阴影是预定模型/窗口所得范围，不是统计置信区间。

![两端系数、比值和相对差](figures_uniformA_dense/coefficients_beta.png)

[PNG](figures_uniformA_dense/coefficients_beta.png) · [PDF](figures_uniformA_dense/coefficients_beta.pdf)

| β | 平衡 c | 非平衡 c | 相对差 | 尺寸漂移 | 移窗漂移 | 阶数漂移 | 局部检查 |
|---:|---:|---:|---:|---:|---:|---:|---|
| 0 | 0.1555236 | 0.1548329 | -0.44% | 0.72% | 0.43% | 0.68% | 通过 |
| 0.1 | 0.1478314 | 0.1488195 | 0.67% | 0.15% | 0.17% | 2.60% | 通过 |
| 0.2 | 0.1284359 | 0.1302423 | 1.41% | 0.03% | 0.42% | 4.54% | 通过 |
| 0.3 | 0.10379 | 0.105623 | 1.77% | 0.01% | 0.56% | 5.75% | 阶数敏感 |
| 0.4 | 0.0793893 | 0.08090481 | 1.91% | 0.00% | 0.63% | 6.39% | 阶数敏感 |
| 0.5 | 0.05833027 | 0.05947269 | 1.96% | 0.00% | 0.66% | 6.71% | 阶数敏感 |
| 0.6 | 0.04164488 | 0.04246655 | 1.97% | 0.00% | 0.67% | 6.86% | 阶数敏感 |
| 0.7 | 0.0291415 | 0.02971715 | 1.98% | 0.00% | 0.67% | 6.93% | 阶数敏感 |
| 0.8 | 0.02011174 | 0.02050872 | 1.97% | 0.00% | 0.68% | 6.96% | 阶数敏感 |
| 0.9 | 0.01374927 | 0.01402035 | 1.97% | 0.00% | 0.68% | 6.98% | 阶数敏感 |
| 1 | 0.009339438 | 0.009523386 | 1.97% | 0.00% | 0.82% | 6.98% | 阶数敏感 |
| 1.1 | 0.006316498 | 0.00644081 | 1.97% | 0.00% | 0.68% | 6.99% | 阶数敏感 |
| 1.2 | 0.004259523 | 0.004343297 | 1.97% | 0.00% | 0.68% | 6.99% | 阶数敏感 |
| 1.3 | 0.002866753 | 0.002923109 | 1.97% | 0.00% | 0.68% | 6.99% | 阶数敏感 |
| 1.4 | 0.001926836 | 0.001964708 | 1.97% | 0.00% | 0.68% | 6.99% | 阶数敏感 |
| 1.5 | 0.001293938 | 0.001319363 | 1.96% | 0.00% | 0.68% | 6.99% | 阶数敏感 |
| 1.6 | 0.0008684061 | 0.0008854625 | 1.96% | 0.00% | 0.68% | 6.99% | 阶数敏感 |
| 1.7 | 0.0005825843 | 0.0005940299 | 1.96% | 0.00% | 0.68% | 6.99% | 阶数敏感 |
| 1.8 | 0.0003907312 | 0.0003984037 | 1.96% | 0.00% | 0.68% | 6.99% | 阶数敏感 |
| 1.9 | 0.0002620109 | 0.000267156 | 1.96% | 0.00% | 0.68% | 6.99% | 阶数敏感 |
| 2 | 0.0001756743 | 0.0001791228 | 1.96% | 0.00% | 0.68% | 6.99% | 阶数敏感 |

表中 0.00% 是显示精度造成的舍入，不表示严格为零；完整数值保存在 CSV 中。局部诊断使用非平衡自身作为归一化：同窗尺寸漂移 ≤2%、窗口及阶数漂移 ≤5%、同点 D 差相对对数变化 ≤1%，且无符号翻转。有第三尺寸时，还要求额外尺寸漂移 ≤2% 且递减。β=0、1 有 L=216 控制，其余 β 只具备两尺寸局部证据。

主窗口的时间跨度不足两倍，五参数同窗检验只有两个残差自由度；这些限制在原始表中明确标出。不能以局部通过替代更宽的尺度分离检验。

本轮检查弱于 [全构型审计](analysis_time_scale/FINDINGS.md) 提出的完整渐近验证建议：尚未在全部 β 完成三个尺寸、所有修正阶数上的尺寸趋势，以及 4…8 到 6…12 的宽范围整体移窗。当前完成的是统一受限窗口下的系数曲线和局部敏感性诊断。

![不使用平衡目标的时间侧诊断](figures_uniformA_dense/time_diagnostics_beta.png)

[PNG](figures_uniformA_dense/time_diagnostics_beta.png) · [PDF](figures_uniformA_dense/time_diagnostics_beta.pdf)

### 提高时间下限后的直接检查

下表固定 L=180，将四参数模型的窗口从 4…7 整体移到 5…8，并检查新窗口的三、四、五参数差。它直接检验早时截断敏感性，不使用平衡系数。5…8 窗口满足 8/180≈0.04444，但本轮没有为全部 β 提供这个完整移窗的另一尺寸验证，因此不凭这张表替换预设主估计。

| β | c：4…7 | c：5…8 | 5…8 最大阶数差 | 5…8 的 L180→216 漂移 | 4…7 修正/对数变化 | 5…8 修正/对数变化 |
|---:|---:|---:|---:|---:|---:|---:|
| 0 | 0.1548329 | 0.1548069 | 1.09% | 0.38% | 13.89% | 11.59% |
| 0.5 | 0.05947269 | 0.05908137 | 4.12% | — | 7.25% | 5.13% |
| 1 | 0.009523386 | 0.009458938 | 4.30% | 0.00% | 9.71% | 5.24% |
| 1.5 | 0.001319363 | 0.001310429 | 4.30% | — | 9.95% | 5.44% |
| 2 | 0.0001791228 | 0.0001779067 | 4.30% | — | 9.98% | 5.46% |

在表中四个正 β 上，阶数差由约 6.71%–6.99% 降为 4.12%–4.30%，说明提高时间下限后早时修正的影响有所减小。这是改善的证据，尚不能替代全部 β 在较晚窗口上的完整尺寸检查。

β=0、1 的 L=216 补点使较晚窗口也有逐点尺寸对照；横线表示其他 β 没有这个第三尺寸。修正/对数变化使用逆时间修正各项变化绝对值之和除以对数项变化；它不会因不同逆幂项的抵消而人为变小。较晚窗口也只有 7 个时间点，仍需保留有限窗口解释。

### 代表性 β 的 scaling 与实际拟合范围

左侧横轴为 ln L，右侧为 ln θ，纵轴保持原始 D。主图显示符合本次几何预筛的尺寸/时间点，拟合仅画在实际采用的窗口内。较晚或较小尺寸的数据继续保存在诊断表，不并入主拟合。

![β=0 的平衡与非平衡 scaling](figures_uniformA_dense/scaling_beta_0.png)

[PNG](figures_uniformA_dense/scaling_beta_0.png) · [PDF](figures_uniformA_dense/scaling_beta_0.pdf)

![β=0.5 的平衡与非平衡 scaling](figures_uniformA_dense/scaling_beta_0p5.png)

[PNG](figures_uniformA_dense/scaling_beta_0p5.png) · [PDF](figures_uniformA_dense/scaling_beta_0p5.pdf)

![β=1 的平衡与非平衡 scaling](figures_uniformA_dense/scaling_beta_1.png)

[PNG](figures_uniformA_dense/scaling_beta_1.png) · [PDF](figures_uniformA_dense/scaling_beta_1.pdf)

![β=1.5 的平衡与非平衡 scaling](figures_uniformA_dense/scaling_beta_1p5.png)

[PNG](figures_uniformA_dense/scaling_beta_1p5.png) · [PDF](figures_uniformA_dense/scaling_beta_1p5.pdf)

![β=2 的平衡与非平衡 scaling](figures_uniformA_dense/scaling_beta_2.png)

[PNG](figures_uniformA_dense/scaling_beta_2.png) · [PDF](figures_uniformA_dense/scaling_beta_2.pdf)

### 数据与复算

- [主系数表](analysis_uniformA_dense/primary_coefficients.csv)、[全部时间敏感性](analysis_uniformA_dense/time_sensitivity.csv)、[平衡拟合](analysis_uniformA_dense/equilibrium_fits.csv)。
- [时间窗口与尺寸共同网格拟合](analysis_uniformA_dense/time_pair_fits.csv)、[逐尺寸拟合](analysis_uniformA_dense/time_individual_fits.csv)。
- [完整来源及分析回执](analysis_uniformA_dense/summary.json)、[原始数据独立核验](analysis_uniformA_dense/independent_data_validation.json)、[80 位精度独立拟合核验](analysis_uniformA_dense/independent_fit_validation.json)。

```powershell
python src/Measure/ai/validate_uniformA_dense.py --stage final
python src/Measure/ai/analyze_uniformA_dense.py --stage final
python src/Measure/ai/audit_uniformA_dense_fits.py --stage final
python src/Measure/ai/write_uniformA_dense_report.py
```

<!-- GENERATED_RESULTS_END -->

## 1. 为什么时间窗口需要两端限制

虚时投影的非平衡 scaling 需要同时避开微观暂态与有限尺寸饱和：

$$
\theta_{\rm micro}\ll\theta,\qquad v\theta\ll\ell_{\rm geom}.
$$

当前最近邻 hopping 单位取 1。θ/L 只是用于安排网格的比例；最窄区域的宽度为 L/3，因此还应报告 θ/(L/3)，并通过不同 L 的同时间网格检验实际尺寸影响。不能把“θ<L”或某个固定比例直接当作渐近区的证明。

新候选窗口采用以下操作性预筛：

$$
\theta_{\min}\ge4,\qquad \frac{\theta_{\max}}{L}\le0.05.
$$

这两个数不是理论保证，θ=4 也不是对所有 β 都已证实的微观时间阈值。仍须检查：提高时间下限、降低时间上限、整体移动窗口以及改变逆时间修正阶数后，系数是否稳定；两个或三个尺寸的同点数据和同模型系数是否收敛。空心未稳定点意味着尚不能确认当前下限已足够大。原始曲线不作纵向平移，不按接近平衡值与否选择时间窗。

先在 β=0、1 增加 L=180、216 的 θ=4…10 数据，再补齐 θ=4、4.5、…、7 的同网格点。密集 β 的主候选窗为 L=144/180 的 θ=4…7，最大比例分别为 0.04861 和 0.03889。另在每个 β 的 L=180 增加 θ=7.5、8，比较整体移动后的 5…8 窗口，其最大比例为 0.04444。这个移窗没有自动获得 L=144 的尺寸验证：8/144 已超过本次预筛门槛。

β=0、1 的第三尺寸 L=216 用于额外检查尺寸趋势，并补充 θ=7.5，使 5…8 的移窗也有完整的同时间网格。不能将这两个 β 的验证自动推广为所有 β 都有三尺寸证据。较晚的数据即使不满足预筛，也保留为诊断，不混入主系数曲线。网格和追加理由见 [分析计划](analysis_uniformA_dense/plan.json)。

## 2. β 网格、熵定义与参考 notebook

uniform A 的 β 网格为 0、0.1、…、2.0，共 21 点。平衡和非平衡都测量初态自身的空 B 亚格点，使用单种费米子、自然对数 Rényi-2 熵。

非平衡数据先从全 A 构型演化有限时间，再施加一次弱测量；平衡数据先取该构型可达的基态极限，再施加同样的测量。这里的 θ 直接对应代码中的演化时间：

$$
|\Psi(\theta,\beta)\rangle\propto
\exp\!\left(-2\beta\sum_{j\in B}\hat n_j\right)
\exp(-\theta\hat H)|F_A\rangle,
\qquad |\Psi_{\rm eq}(\beta)\rangle=\lim_{\theta\to\infty}|\Psi(\theta,\beta)\rangle.
$$

文中的“平衡”沿用原任务的命名，指基态准备完成后测量所得的态；正 β 的测量后态通常不再是原 Hamiltonian 的基态。

$$
S_2(A)=-\ln\det\!\left[C_A^2+(I-C_A)^2\right],
\qquad D=\frac{2S_A+S_C}{3}-S_B.
$$

uniform A 具有两个方向的交换对称性，数值检查 S_A=S_C，因此这里 D=S_A−S_B。

本次参考的 [ForcePD.ipynb](../Force/victory/A_B/ForcePD.ipynb) 与这里使用相同的单种熵定义，**不应套用另一个 Ref notebook 的两倍归一化**。本次保留其 β/α 线性坐标、网格和零水平线，并使用不同线型、不同大小的圆形/方形标记及 legend，让重叠的平衡和非平衡结果仍能区分。

参考 notebook 保存的拟合使用 L=3、6、…、21 的纯对数模型，β=0.1、0.15、…、3.0。新计算使用更大尺寸和修正项，所以不能要求它们的有限尺寸拟合值逐点相等。已只读核验保存数据和图，59 个已保存系数独立复算最大差为 4.45×10⁻¹⁶；14 个同参数熵差与本代码的比值接近 1，归一化核验见 [notebook 审计](analysis_uniformA_dense/ref_notebook/inspection_summary.json)。

## 3. 拟合与数值核验

平衡从不同尺寸拟合，非平衡从固定 L 的时间序列独立拟合：

$$
D_{\rm eq}(L)=c_{\rm eq}\ln L+b+d/L+\cdots,
$$

$$
D_L(\theta)=c_\theta\ln\theta+b+d/\theta+e/\theta^2+\cdots.
$$

每个模型采用各点等权的最小二乘拟合，至少保留两个残差自由度。不同模型、截断和尺寸导致的范围表示拟合敏感性，不是统计置信区间。对数 scaling 图直接使用 ln L 或 ln θ 横坐标；系数图使用 β 横坐标。

表格中的两端相对差采用下式，并以百分比显示；时间侧的尺寸、移窗和阶数漂移则使用非平衡系数自身归一化。

$$
\delta_c=\frac{c_\theta-c_{\rm eq}}{|c_{\rm eq}|}.
$$

新增计算保持原来的有限虚时演化和测量内核。矩形熵使用经验证的 uniform A 精确降维公式以减少运算量；它保留全部动量和 Dirac 零模，不将有限 θ 替换成基态。24 个小尺寸例子与完整相关矩阵的熵最大差为 1.30×10⁻¹²；L=180 的大矩阵交叉检查差为 4.98×10⁻¹³。

- [计算脚本](uniformA_dense_experiments.jl) 与 [可选精确熵扩展](uniformA_entropy_extension.jl)。
- [小尺寸完整矩阵交叉核验](analysis_uniformA_dense/half_entropy_validation.toml)。
- [精确降维推导](analysis_uniformA_dense/HALF_ENTROPY.md)：全部谱与零模均保留。
- [独立原始数据核验脚本](validate_uniformA_dense.py)：检查复用来源、逐行哈希、运行参数、源码快照及数值恒等式。

最终系数需同时通过窗口和尺寸检查；若未通过，应标为未解决的有限窗口估计，不能把曲线接近平衡一侧当作验证依据。

## 4. 复算计算网格

以下命令在仓库根目录顺序执行。脚本复用已存在的同参数原始值并记录来源；缺少的点才会计算，因此可以断点继续。将 `--mode=run` 改成 `--mode=plan` 可先查看缺失点数。

```powershell
julia --project=. src/Measure/ai/uniformA_dense_experiments.jl --mode=run --method=halfcomplex --threads=8 --Ls=18:6:90,108,126,144 --thetas=Inf --betas=0:0.1:2
julia --project=. src/Measure/ai/uniformA_dense_experiments.jl --mode=run --method=halfcomplex --threads=8 --Ls=144,180 --thetas=4:0.5:7 --betas=0:0.1:2
julia --project=. src/Measure/ai/uniformA_dense_experiments.jl --mode=run --method=halfcomplex --threads=8 --Ls=180 --thetas=7.5,8 --betas=0:0.1:2
julia --project=. src/Measure/ai/uniformA_dense_experiments.jl --mode=run --method=halfcomplex --threads=8 --Ls=180,216 --thetas=4:1:10 --betas=0,1
julia --project=. src/Measure/ai/uniformA_dense_experiments.jl --mode=run --method=halfcomplex --threads=8 --Ls=216 --thetas=4:0.5:8 --betas=0,1
```

随后运行本页结果部分列出的 Python 分析和独立核验命令。每次实际运行的参数、源码哈希、输出行与数值检查保存在 `data/uniformA_dense_run_*.toml`，原始值和逐行来源分别保存在 [CSV](data/uniformA_dense_observations.csv) 与 [TSV](data/uniformA_dense_observations_provenance.tsv)。
