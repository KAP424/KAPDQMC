# 构型初态、虚时演化与弱测量实验

新增 `one_B_2`、`diagonal_B_3`、`random_half_3` 的 β=0、0.25、…、2 扫描见 [BETA_PATTERNS.md](BETA_PATTERNS.md)：包含三构型的平衡/非平衡系数同图比较、ln L / ln θ scaling 与拟合，以及尺寸、移窗和模型检查。共 909 个参数点；未稳定的有限窗口估计已单独标记。

uniform A 的最新时间窗口复核与 β 加密扫描见 [UNIFORM_A_DENSE.md](UNIFORM_A_DENSE.md)。全部构型的早期窗口诊断仍见 [REF_CALIBRATION.md](REF_CALIBRATION.md)；统一 θ=2…6 不能当作已经确认尺度分离的渐近窗口，原因见 [时间尺度审计](analysis_time_scale/FINDINGS.md)。

旧有限窗口的通过/失败名单、旧系数摘要和过期图集已撤下。原始数据保留；尚未稳定的观测用于诊断，不能直接解释为渐近系数不同或 scaling 不存在。

| 入口 | 内容 |
|---|---|
| [BETA_PATTERNS.md](BETA_PATTERNS.md) | 三个额外可达基态构型、各 9 个 β、27 组平衡/非平衡对照与完整核验 |
| [UNIFORM_A_DENSE.md](UNIFORM_A_DENSE.md) | uniform A 的 β=0…2 加密曲线、受限时间窗口及独立核验 |
| [REF_CALIBRATION.md](REF_CALIBRATION.md) | 全构型早期窗口诊断、Ref 校准、拟合敏感性与复现方式 |
| [SCALING_GUIDE.md](SCALING_GUIDE.md) | 区域几何、构型图示、基态投影判据及结论边界 |
| [EQUILIBRIUM.md](EQUILIBRIUM.md) | 独立平衡实验、原始区域熵和面积项检查 |
| [RANDOM_HALF3_BETA1.md](RANDOM_HALF3_BETA1.md) | random_half_3、β=1 扩展至 L=216 的专项 |
| [neq.md](neq.md) | 任务原文 |

采用周期 HoneyComb120、实数等强最近邻 hopping、半填充单种自由费米子和自然对数 Rényi-2 熵。两份独立相同自旋的熵是这里单种结果的两倍。

occupied_bits 按 A(1,1),B(1,1),A(2,1),B(2,1),… 排列，x 先变、y 后变。special 表示每原胞恰有一个粒子；general 允许空原胞和双占据原胞。改变初态时，测量集合也取该初态自身空位，因而比较的是整个制备与测量协议。

theta=Inf 表示初态可达的无限虚时极限，只有通过测量前的能量与谱检查，才能称为基态数据。测量后能量不必等于原 Hamiltonian 的基态能量。

原始观测、构型普查、计算清单与数值检查保留在 [data/](data/)。uniform A 加密扫描的分析入口为 [analyze_uniformA_dense.py](analyze_uniformA_dense.py)，拟合与来源记录位于 [analysis_uniformA_dense/](analysis_uniformA_dense/)。全构型早期窗口的分析入口为 [analyze_ref_calibration.py](analyze_ref_calibration.py)，记录位于 [analysis_ref_calibration/](analysis_ref_calibration/)。独立平衡原始数据见 [equilibrium_extended.csv](data/equilibrium_extended.csv) 和 [equilibrium_arrangements.csv](data/equilibrium_arrangements.csv)；基础计算实现见 [fermion_experiment.jl](fermion_experiment.jl)。
