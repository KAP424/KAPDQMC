"""Insert final, audited dense-beta results into the scientific explanation."""
from pathlib import Path
import csv
import hashlib
import json
import math

ROOT = Path(__file__).resolve().parent
ANA = ROOT / "analysis_uniformA_dense"
FIG = ROOT / "figures_uniformA_dense"
START, END = "<!-- GENERATED_RESULTS_START -->", "<!-- GENERATED_RESULTS_END -->"


def read(name):
    return list(csv.DictReader((ANA/name).open(encoding="utf-8-sig", newline="")))


def value(row, name):
    return float(row[name]) if row.get(name) else math.nan


def fmt(number):
    return f"{number:.7g}" if math.isfinite(number) else "—"


def pct(number):
    return f"{100*number:.2f}%" if math.isfinite(number) else "—"


def image(stem, caption):
    assert (FIG/(stem+".png")).exists() and (FIG/(stem+".pdf")).exists()
    return f"![{caption}](figures_uniformA_dense/{stem}.png)\n\n[PNG](figures_uniformA_dense/{stem}.png) · [PDF](figures_uniformA_dense/{stem}.pdf)\n"


def main():
    summary = json.loads((ANA/"summary.json").read_text(encoding="utf-8"))
    rawcheck = json.loads((ANA/"independent_data_validation.json").read_text(encoding="utf-8"))
    fitcheck = json.loads((ANA/"independent_fit_validation.json").read_text(encoding="utf-8"))
    assert summary["stage"] == "final" and summary["required_grid_complete"] and summary["primary_complete"]
    for check in (rawcheck, fitcheck):
        assert check["status"] == "PASS" and check["stage"] == "final"
    assert fitcheck["primary_summary_sha256"] == hashlib.sha256((ANA/"summary.json").read_bytes()).hexdigest()
    for name, digest in fitcheck["fit_table_sha256"].items():
        assert hashlib.sha256((ANA/name).read_bytes()).hexdigest() == digest, name
    rawpath = ROOT/"data/uniformA_dense_observations.csv"
    rawhash = hashlib.sha256(rawpath.read_bytes()).hexdigest()
    assert rawhash == rawcheck["outputs"][rawpath.name]["sha256"]
    fit_source = next(r for r in fitcheck["source_receipts"] if Path(r["path"]).resolve() == rawpath.resolve())
    assert rawhash == fit_source["source_sha256"]
    coefficients = read("primary_coefficients.csv")
    assert len(coefficients) == 21 and all(r.get("c_eq") and r.get("c_neq") for r in coefficients)
    actual = list(csv.DictReader((ROOT/"data/uniformA_dense_observations.csv").open(encoding="utf-8-sig")))
    computed = sum(r["source_kind"] == "computed" for r in actual)
    eq = sum(math.isinf(float(r["theta"])) for r in actual)
    passed = [r for r in coefficients if r["local_diagnostic_pass"] == "True"]
    passed_beta = "、".join(f"{value(r,'beta'):g}" for r in passed)
    gap = max(abs(value(r,"relative_gap")) for r in coefficients)
    parts = [START, "## 本轮完成的结果\n",
             f"β=0、0.1、…、2.0 的 **21 个点已完成**。本轮记录 {len(actual)} 个参数点，其中 {eq} 个平衡点、{len(actual)-eq} 个有限时间点；{computed} 点新计算、{len(actual)-computed} 点按原始值复用。所要求的网格完整，原始数据与独立高精度拟合核验均通过。\n",
             "主平衡系数使用 L=18…144 的对数加逆尺寸修正；主非平衡系数使用 L=180、θ=4、4.5、…、7 的四参数模型，并在 L=144 的同时间网格上检查尺寸变化。每个 β 另检查 L=180 的 5…8 移窗，以及不同修正阶数。\n",
             f"两端主估计的相对差最大为 **{pct(gap)}**。{len(passed)}/21 个 β（{passed_beta}）通过本页列明的局部诊断；这仍是有限数据检查，不是渐近相等的定理。图中空心非平衡方块表示本页必需的局部检查未通过或缺失，其值只作诊断；实心非平衡方块也不代表已有第三尺寸验证。\n",
             "平衡结果使用较粗的蓝色实线和大空心圆，非平衡结果使用橙色虚线和较小方块。重叠时仍可见虚线间的蓝线及方块外的圆环；数据坐标没有偏移。蓝色空心圆只表示平衡数据，不表示未通过局部检查。\n",
             image("corner_coefficient_beta", "uniform A 的平衡与非平衡角贡献系数随 β 变化"),
             "下图补充系数比值和相对差，避免在强测量的小信号区只看线性纵轴就误以为两条曲线完全重合。阴影是预定模型/窗口所得范围，不是统计置信区间。\n",
             image("coefficients_beta", "两端系数、比值和相对差"),
             "| β | 平衡 c | 非平衡 c | 相对差 | 尺寸漂移 | 移窗漂移 | 阶数漂移 | 局部检查 |\n|---:|---:|---:|---:|---:|---:|---:|---|"]
    for r in coefficients:
        state = '通过' if r['local_diagnostic_pass']=='True' else '阶数敏感' if value(r,'model_drift')>.05 else '未稳定/缺检查'
        parts.append(f"| {value(r,'beta'):g} | {fmt(value(r,'c_eq'))} | {fmt(value(r,'c_neq'))} | {pct(value(r,'relative_gap'))} | {pct(value(r,'size_drift'))} | {pct(value(r,'window_drift'))} | {pct(value(r,'model_drift'))} | {state} |")
    parts.extend(["\n表中 0.00% 是显示精度造成的舍入，不表示严格为零；完整数值保存在 CSV 中。局部诊断使用非平衡自身作为归一化：同窗尺寸漂移 ≤2%、窗口及阶数漂移 ≤5%、同点 D 差相对对数变化 ≤1%，且无符号翻转。有第三尺寸时，还要求额外尺寸漂移 ≤2% 且递减。β=0、1 有 L=216 控制，其余 β 只具备两尺寸局部证据。\n",
                  "主窗口的时间跨度不足两倍，五参数同窗检验只有两个残差自由度；这些限制在原始表中明确标出。不能以局部通过替代更宽的尺度分离检验。\n",
                  "本轮检查弱于 [全构型审计](analysis_time_scale/FINDINGS.md) 提出的完整渐近验证建议：尚未在全部 β 完成三个尺寸、所有修正阶数上的尺寸趋势，以及 4…8 到 6…12 的宽范围整体移窗。当前完成的是统一受限窗口下的系数曲线和局部敏感性诊断。\n",
                  image("time_diagnostics_beta", "不使用平衡目标的时间侧诊断"),
                  "### 提高时间下限后的直接检查\n\n下表固定 L=180，将四参数模型的窗口从 4…7 整体移到 5…8，并检查新窗口的三、四、五参数差。它直接检验早时截断敏感性，不使用平衡系数。5…8 窗口满足 8/180≈0.04444，但本轮没有为全部 β 提供这个完整移窗的另一尺寸验证，因此不凭这张表替换预设主估计。\n",
                  "| β | c：4…7 | c：5…8 | 5…8 最大阶数差 | 5…8 的 L180→216 漂移 | 4…7 修正/对数变化 | 5…8 修正/对数变化 |\n|---:|---:|---:|---:|---:|---:|---:|"])
    individual = read("time_individual_fits.csv")
    cutoff_checks = []
    for beta in (0,.5,1,1.5,2):
        primary = next(r for r in coefficients if value(r,"beta") == beta)
        shifted = [r for r in individual if value(r,"beta") == beta and value(r,"L") == 180 and r["window"] == "5-8"]
        assert len(shifted) == 3 and all(value(r,"n") == 7 for r in shifted)
        anchor = next(r for r in shifted if r["model"] == "log_inv1_inv2")
        c = value(anchor,"c")
        drift = max(abs(value(r,"c")-c)/abs(c) for r in shifted)
        if beta > 0:
            cutoff_checks.append((value(primary,"model_drift"),drift))
        third = next((r for r in individual if value(r,"beta") == beta and value(r,"L") == 216 and r["window"] == "5-8" and r["model"] == "log_inv1_inv2"),None)
        third_drift = abs(value(third,"c")-c)/abs(value(third,"c")) if third else math.nan
        if third:
            assert value(third,"n") == 7 and third["grid"] == anchor["grid"]
        parts.append(f"| {beta:g} | {fmt(value(primary,'c_neq'))} | {fmt(c)} | {pct(drift)} | {pct(third_drift)} | {pct(value(primary,'correction_to_log_span'))} | {pct(value(anchor,'total_correction_to_log_span'))} |")
    early, late = zip(*cutoff_checks)
    parts.extend([f"\n在表中四个正 β 上，阶数差由约 {pct(min(early))}–{pct(max(early))} 降为 {pct(min(late))}–{pct(max(late))}，说明提高时间下限后早时修正的影响有所减小。这是改善的证据，尚不能替代全部 β 在较晚窗口上的完整尺寸检查。\n",
                  "β=0、1 的 L=216 补点使较晚窗口也有逐点尺寸对照；横线表示其他 β 没有这个第三尺寸。修正/对数变化使用逆时间修正各项变化绝对值之和除以对数项变化；它不会因不同逆幂项的抵消而人为变小。较晚窗口也只有 7 个时间点，仍需保留有限窗口解释。\n",
                  "### 代表性 β 的 scaling 与实际拟合范围\n\n左侧横轴为 ln L，右侧为 ln θ，纵轴保持原始 D。主图显示符合本次几何预筛的尺寸/时间点，拟合仅画在实际采用的窗口内。较晚或较小尺寸的数据继续保存在诊断表，不并入主拟合。\n"])
    for beta in (0,.5,1,1.5,2):
        parts.append(image(f"scaling_beta_{beta:g}".replace(".","p"), f"β={beta:g} 的平衡与非平衡 scaling"))
    parts.extend(["### 数据与复算\n",
                  "- [主系数表](analysis_uniformA_dense/primary_coefficients.csv)、[全部时间敏感性](analysis_uniformA_dense/time_sensitivity.csv)、[平衡拟合](analysis_uniformA_dense/equilibrium_fits.csv)。\n- [时间窗口与尺寸共同网格拟合](analysis_uniformA_dense/time_pair_fits.csv)、[逐尺寸拟合](analysis_uniformA_dense/time_individual_fits.csv)。\n- [完整来源及分析回执](analysis_uniformA_dense/summary.json)、[原始数据独立核验](analysis_uniformA_dense/independent_data_validation.json)、[80 位精度独立拟合核验](analysis_uniformA_dense/independent_fit_validation.json)。\n",
                  "```powershell\npython src/Measure/ai/validate_uniformA_dense.py --stage final\npython src/Measure/ai/analyze_uniformA_dense.py --stage final\npython src/Measure/ai/audit_uniformA_dense_fits.py --stage final\npython src/Measure/ai/write_uniformA_dense_report.py\n```\n", END])
    path = ROOT / "UNIFORM_A_DENSE.md"
    body = path.read_text(encoding="utf-8")
    body = body.replace("本页正在更新新增计算的结果。原始数据逐行写入 `data/uniformA_dense_*.csv`，最终图和拟合将在扫描及独立核验完成后给出。", "新增扫描、重新拟合及独立核验已完成。下面先给出 β 曲线和系数表，再说明时间窗限制与参考 notebook 的关系。")
    rendered = "\n".join(parts)
    if START in body:
        a, tail = body.split(START, 1)
        _, b = tail.split(END, 1)
        body = a + rendered + b
    else:
        body = body.replace("## 1. 为什么时间窗口需要两端限制", rendered+"\n\n## 1. 为什么时间窗口需要两端限制")
    path.write_text(body, encoding="utf-8")
    print(f"Wrote {path.name}; 21 beta values; {len(passed)} local checks passed")


if __name__ == "__main__":
    main()
