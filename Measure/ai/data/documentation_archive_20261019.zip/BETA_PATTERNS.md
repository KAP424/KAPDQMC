# 另外三个可达基态构型：平衡与非平衡的 β 扫描

已完成三个构型的 β=0、0.25、…、2.0，共 **27 组平衡与非平衡系数对照**。本轮主表记录 909 个参数点，其中 653 点新计算、256 点按同一协议复用；原始值、来源和独立拟合核验均已保存。

**下图是统一有限窗口下的拟合结果。只有通过尺寸、移窗和模型检查的非平衡点，才有较强的局部稳定性证据；未通过的点不能用来断言渐近系数不同，也不能作为 scaling 不存在的反例。**

![三个构型的平衡和非平衡D的有限窗口对数系数随beta变化](figures_beta_patterns/corner_coefficients_comparison.png)

[PNG](figures_beta_patterns/corner_coefficients_comparison.png) · [PDF](figures_beta_patterns/corner_coefficients_comparison.pdf)

蓝色粗实线及大空心圆表示平衡结果，橙色虚线及小方块表示非平衡结果；即使数值重合，两种标记仍可见，坐标没有人为错开。非平衡实心方块表示通过本页局部检查，空心方块表示仍未稳定；蓝色空心圆只区分数据系列。

## 怎样读这次比较

下表汇总主估计的比较范围。相对差取 (非平衡−平衡)/|平衡|；它描述当前拟合的差异，不是统计显著性。局部检查只针对有限虚时侧，平衡侧的尺寸及模型敏感性另外列在细节图中。

| 构型 | β=0 的平衡 / 非平衡系数 | 全部 β 的相对差范围 | 非平衡局部检查通过的 β |
|---|---:|---:|---|
| `one_B_2` | 0.1604689 / 0.1581672 | -1.43% 至 11.10% | 0、0.25 |
| `diagonal_B_3` | 0.1608675 / 0.156744 | -2.56% 至 81.66% | 0.5 |
| `random_half_3` | 0.1573072 / 0.1552769 | -1.29% 至 115.62% | 无 |

平衡主拟合中，`one_B_2`、`diagonal_B_3` 的系数在所扫 β 点上随 β 下降；`random_half_3` 则先升后降，网格峰值为 β=1.25、c=0.2198317。这里只报告采样点的峰值，不作连续 β 的精确峰位推断。

`random_half_3` 的非平衡主估计在 β=1.5 达到网格峰值 c=0.3936284，但本构型的九个非平衡点均未通过局部检查。因此图中的幅度和峰位差异仍是有限窗口估计的差异，不能据此认定渐近角系数或其峰位不同。

这里比较的是每个构型各自的平衡与非平衡曲线。改变构型也会改变弱测量的空间图案，因此不同构型在正 β 下不必具有相同系数。

## 构型与计算协议

| 构型 | 占据结构 | 本轮 β 点数 |
|---|---|---:|
| `one_B_2` | 2×2 超胞，每胞单占：3 个 A、1 个 B | 9 |
| `diagonal_B_3` | 3×3 超胞，每胞单占：6 个 A、3 个 B，B 沿对角线排列 | 9 |
| `random_half_3` | 3×3 固定一般构型：5 个 A、4 个 B，含一个双占胞和一个空胞 | 9 |

占据图集中保留在 [SCALING_GUIDE.md](SCALING_GUIDE.md#2-构型占据图)，不在各报告重复绘制。`random_half_3` 是固定的同一个图案，不是在每次计算时重新随机采样。图案、空位测量集合和切口原点均固定。

各个新尺寸均重新检查无限虚时极限的能量及残差，确认这些初态可以投影到基态。这里的“平衡”沿用项目定义：先投影到基态，再施加相同 β 的弱测量；“非平衡”是在有限 θ 演化后再施加该弱测量。测量后的态并不要求仍是原哈密顿量的基态。

采用同一个周期蜂窝晶格、半填充、单种自由费米子的自然对数 Rényi-2 熵。测量集合取各构型自身的初始空位，权重为 exp(−2β)。两个方向条带熵分别计算，未假定它们相等。几何组合与符号为：

$$
D=\frac{2S_2(A)+S_2(C)}{3}-S_2(B),\qquad A=(L/3)\times L,\quad C=L\times(L/3),\quad B=(L/3)\times(2L/3).
$$

这里报告 D 的对数拟合系数。要把它进一步解释为纯粹的普适角系数，仍需面积项正确抵消、非角对数项可控，以及有限尺寸/时间修正已收敛；不能只凭高拟合优度得出该结论。沿蜂窝晶格原矢取区域时，B 在实空间有两个 60° 角和两个 120° 角。这里取四个角贡献之和，未除以角的个数；各角贡献还可能依赖两边方向、构型和 β。只有角函数仅依赖夹角时，才能进一步简写为：

$$
c_B=\sum_{j=1}^{4}a_{2,j},\qquad c_B=2a_2(\pi/3)+2a_2(2\pi/3)\quad\text{（角函数仅依赖夹角时）}.
$$

本轮未额外证明各个测量图案下的方向独立性，因此实际数据始终按 D 的总对数拟合系数报告。

## 实际网格与拟合

平衡：`one_B_2` 取 L=18、24、…、90，再加 108、126、144；两个 3×3 构型取 L=18、27、…、90，再加 108、126、144。所有尺寸均满足 L 能被 3m 整除，切口原点为 (1,1)。主拟合为：

$$
D_{\rm eq}(L)=c_{\rm eq}\ln L+b+\frac{d}{L}.
$$

另改变最小尺寸为 36、54，并加入逆平方修正，完整结果保存在平衡拟合表中。蓝色系数也是 L=18–144 的有限尺寸估计；非平衡局部检查通过，不能替代平衡侧的尺寸及模型稳定性检查，两端数值接近也不等于双方都已渐近收敛。

非平衡：每个 β 均计算 L=144、180 的 θ=4、4.5、…、7；L=180 另加 θ=7.5、8，检验 5–8 移窗。β=0、1、2 进一步计算 L=180、216 的 θ=4、4.5、…、9，检验第三尺寸及 6–9 窗口。统一主拟合为 L=180、θ=4–7：

$$
D_{\rm neq}(\theta)=c_{\rm neq}\ln\theta+b+\frac{d}{\theta}+\frac{e}{\theta^2}.
$$

主估计和图中时间数据按 θ≥4 且 θ/L≤0.05 筛选，并在完全相同时间点上比较尺寸；CSV 中另保留未通过筛选的旧数据拟合作为诊断。θ/L≤0.05 是操作筛选，不能单独证明 θ≫微观尺度且 θ≪L；窄区域宽度 L/3 和速度因子也会影响尺度分离。θ=4–7 只跨越 1.75 倍，五参数诊断只有两个残差自由度，因此保留有限窗口解释。

局部检查沿用 uniform A 的预设规则：系数尺寸漂移≤2%、同点 D 差/拟合对数变化≤1%、移窗及阶数漂移≤5%，且没有变号、检查项齐全。若存在第三尺寸，还要求其漂移≤2% 且递减。除 β=0、1、2 外，其余 β 只有两个尺寸的局部证据。所有窗口按时间侧稳定性检查，不以接近平衡结果作为选择标准。β=0、1、2 的独立时间侧校准详见 [三个窗口的完整比较](analysis_beta_patterns/calibration_review.md)。

## 大尺寸时间校准的结果

这一步只使用 L=180、216 的有限时间数据，独立于平衡系数。下表的‘通过窗口’同时检查尺寸差和修正模型；只有相邻窗口也一致，才多一层移窗稳定证据。它与后文使用 L=144、180 的统一主估计不是同一个检查，不能混用通过标记。

| 构型 | β | 通过局部检查的窗口 | 通过的相邻窗口比较 |
|---|---:|---|---|
| `one_B_2` | 0 | 4-7、5-8、6-9 | 4-7 -> 5-8；5-8 -> 6-9 |
| `one_B_2` | 1 | 6-9 | 无 |
| `one_B_2` | 2 | 6-9 | 无 |
| `diagonal_B_3` | 0 | 5-8、6-9 | 5-8 -> 6-9 |
| `diagonal_B_3` | 1 | 无 | 无 |
| `diagonal_B_3` | 2 | 无 | 无 |
| `random_half_3` | 0 | 无 | 无 |
| `random_half_3` | 1 | 无 | 无 |
| `random_half_3` | 2 | 无 | 无 |

**增大虚时并不自动改善所有构型。** 例如 `random_half_3` 的 β=0 四参数拟合，在 L=180、216 间的系数漂移随窗口后移而增大；而部分正 β 数据的两个尺寸很接近，修正模型给出的系数却相差明显。原始 D 重合和拟合残差小，都不足以单独确认对数系数收敛。完整读数及未通过项见上述校准报告。

## 三个构型的结果

### one_B_2

![one_B_2的系数随beta变化](figures_beta_patterns/one_B_2_corner_coefficient_beta.png)

[PNG](figures_beta_patterns/one_B_2_corner_coefficient_beta.png) · [PDF](figures_beta_patterns/one_B_2_corner_coefficient_beta.pdf)

改变平衡拟合的最小尺寸或修正阶数后，相对主系数的最大变化为 **1.57%**，出现在 β=0。这是本次预定拟合间的敏感性，不是统计置信区间。

当前局部检查通过的 β：**0、0.25**。下表给出全部九个 β；相对差定义为 (非平衡−平衡)/|平衡|，不是误差条或统计显著性。

| β | 平衡 c | 非平衡 c | 相对差 | 尺寸漂移 | 移窗漂移 | 阶数漂移 | 非平衡检查 |
|---:|---:|---:|---:|---:|---:|---:|---|
| 0 | 0.1604689 | 0.1581672 | -1.43% | 0.59% | 0.72% | 4.26% | 通过局部检查 |
| 0.25 | 0.1490703 | 0.1492134 | 0.10% | 0.12% | 0.12% | 1.36% | 通过局部检查 |
| 0.5 | 0.1274274 | 0.1320432 | 3.62% | 0.03% | 1.94% | 5.96% | 阶数 |
| 0.75 | 0.10042 | 0.109156 | 8.70% | 0.01% | 4.75% | 14.22% | 阶数 |
| 1 | 0.06742882 | 0.07484606 | 11.00% | 0.00% | 8.40% | 16.26% | 移窗、阶数 |
| 1.25 | 0.03642392 | 0.04046621 | 11.10% | 0.00% | 6.05% | 15.13% | 移窗、阶数 |
| 1.5 | 0.01627426 | 0.01803891 | 10.84% | 0.00% | 5.92% | 14.33% | 移窗、阶数 |
| 1.75 | 0.006505095 | 0.007200186 | 10.69% | 0.00% | 5.84% | 14.02% | 移窗、阶数 |
| 2 | 0.002472039 | 0.002734469 | 10.62% | 0.00% | 8.24% | 13.91% | 移窗、阶数 |

下图同时显示系数、比值和相对差，阴影是预定模型/窗口的敏感性范围，**不是统计置信区间**。

![one_B_2系数敏感性、比值与相对差](figures_beta_patterns/one_B_2_coefficient_diagnostics.png)

[PNG](figures_beta_patterns/one_B_2_coefficient_diagnostics.png) · [PDF](figures_beta_patterns/one_B_2_coefficient_diagnostics.pdf)

代表性 β 的原始 D 与拟合如下：左图横轴为 ln L，右图为 ln θ；拟合线只画在实际使用的窗口内，包含所声明的逆尺度修正，并非强制直线。

![one_B_2 beta=0平衡与非平衡标度](figures_beta_patterns/one_B_2_scaling_beta_0.png)

[PNG](figures_beta_patterns/one_B_2_scaling_beta_0.png) · [PDF](figures_beta_patterns/one_B_2_scaling_beta_0.pdf)

![one_B_2 beta=0.5平衡与非平衡标度](figures_beta_patterns/one_B_2_scaling_beta_0p5.png)

[PNG](figures_beta_patterns/one_B_2_scaling_beta_0p5.png) · [PDF](figures_beta_patterns/one_B_2_scaling_beta_0p5.pdf)

![one_B_2 beta=1平衡与非平衡标度](figures_beta_patterns/one_B_2_scaling_beta_1.png)

[PNG](figures_beta_patterns/one_B_2_scaling_beta_1.png) · [PDF](figures_beta_patterns/one_B_2_scaling_beta_1.pdf)

![one_B_2 beta=1.5平衡与非平衡标度](figures_beta_patterns/one_B_2_scaling_beta_1p5.png)

[PNG](figures_beta_patterns/one_B_2_scaling_beta_1p5.png) · [PDF](figures_beta_patterns/one_B_2_scaling_beta_1p5.pdf)

![one_B_2 beta=2平衡与非平衡标度](figures_beta_patterns/one_B_2_scaling_beta_2.png)

[PNG](figures_beta_patterns/one_B_2_scaling_beta_2.png) · [PDF](figures_beta_patterns/one_B_2_scaling_beta_2.pdf)

### diagonal_B_3

![diagonal_B_3的系数随beta变化](figures_beta_patterns/diagonal_B_3_corner_coefficient_beta.png)

[PNG](figures_beta_patterns/diagonal_B_3_corner_coefficient_beta.png) · [PDF](figures_beta_patterns/diagonal_B_3_corner_coefficient_beta.pdf)

改变平衡拟合的最小尺寸或修正阶数后，相对主系数的最大变化为 **7.63%**，出现在 β=2。这是本次预定拟合间的敏感性，不是统计置信区间。

当前局部检查通过的 β：**0.5**。下表给出全部九个 β；相对差定义为 (非平衡−平衡)/|平衡|，不是误差条或统计显著性。

| β | 平衡 c | 非平衡 c | 相对差 | 尺寸漂移 | 移窗漂移 | 阶数漂移 | 非平衡检查 |
|---:|---:|---:|---:|---:|---:|---:|---|
| 0 | 0.1608675 | 0.156744 | -2.56% | 0.76% | 0.87% | 8.31% | 阶数 |
| 0.25 | 0.1565537 | 0.1533302 | -2.06% | 0.22% | 0.95% | 8.86% | 阶数 |
| 0.5 | 0.1434669 | 0.1417491 | -1.20% | 0.06% | 0.47% | 4.99% | 通过局部检查 |
| 0.75 | 0.1195466 | 0.1232697 | 3.11% | 0.01% | 1.49% | 6.14% | 阶数 |
| 1 | 0.08403503 | 0.09656818 | 14.91% | 0.00% | 9.35% | 28.03% | 移窗、阶数 |
| 1.25 | 0.04639887 | 0.06262447 | 34.97% | 0.00% | 11.22% | 57.98% | 移窗、阶数 |
| 1.5 | 0.02070907 | 0.03260606 | 57.45% | 0.00% | 14.91% | 82.93% | 移窗、阶数 |
| 1.75 | 0.008218309 | 0.01426044 | 73.52% | 0.00% | 16.74% | 96.44% | 移窗、阶数 |
| 2 | 0.003108257 | 0.00564634 | 81.66% | 0.00% | 29.75% | 102.23% | 移窗、阶数、变号 |

下图同时显示系数、比值和相对差，阴影是预定模型/窗口的敏感性范围，**不是统计置信区间**。

![diagonal_B_3系数敏感性、比值与相对差](figures_beta_patterns/diagonal_B_3_coefficient_diagnostics.png)

[PNG](figures_beta_patterns/diagonal_B_3_coefficient_diagnostics.png) · [PDF](figures_beta_patterns/diagonal_B_3_coefficient_diagnostics.pdf)

代表性 β 的原始 D 与拟合如下：左图横轴为 ln L，右图为 ln θ；拟合线只画在实际使用的窗口内，包含所声明的逆尺度修正，并非强制直线。

![diagonal_B_3 beta=0平衡与非平衡标度](figures_beta_patterns/diagonal_B_3_scaling_beta_0.png)

[PNG](figures_beta_patterns/diagonal_B_3_scaling_beta_0.png) · [PDF](figures_beta_patterns/diagonal_B_3_scaling_beta_0.pdf)

![diagonal_B_3 beta=0.5平衡与非平衡标度](figures_beta_patterns/diagonal_B_3_scaling_beta_0p5.png)

[PNG](figures_beta_patterns/diagonal_B_3_scaling_beta_0p5.png) · [PDF](figures_beta_patterns/diagonal_B_3_scaling_beta_0p5.pdf)

![diagonal_B_3 beta=1平衡与非平衡标度](figures_beta_patterns/diagonal_B_3_scaling_beta_1.png)

[PNG](figures_beta_patterns/diagonal_B_3_scaling_beta_1.png) · [PDF](figures_beta_patterns/diagonal_B_3_scaling_beta_1.pdf)

![diagonal_B_3 beta=1.5平衡与非平衡标度](figures_beta_patterns/diagonal_B_3_scaling_beta_1p5.png)

[PNG](figures_beta_patterns/diagonal_B_3_scaling_beta_1p5.png) · [PDF](figures_beta_patterns/diagonal_B_3_scaling_beta_1p5.pdf)

![diagonal_B_3 beta=2平衡与非平衡标度](figures_beta_patterns/diagonal_B_3_scaling_beta_2.png)

[PNG](figures_beta_patterns/diagonal_B_3_scaling_beta_2.png) · [PDF](figures_beta_patterns/diagonal_B_3_scaling_beta_2.pdf)

### random_half_3

![random_half_3的系数随beta变化](figures_beta_patterns/random_half_3_corner_coefficient_beta.png)

[PNG](figures_beta_patterns/random_half_3_corner_coefficient_beta.png) · [PDF](figures_beta_patterns/random_half_3_corner_coefficient_beta.pdf)

改变平衡拟合的最小尺寸或修正阶数后，相对主系数的最大变化为 **3.29%**，出现在 β=1.75。这是本次预定拟合间的敏感性，不是统计置信区间。

当前局部检查通过的 β：**无**。下表给出全部九个 β；相对差定义为 (非平衡−平衡)/|平衡|，不是误差条或统计显著性。

| β | 平衡 c | 非平衡 c | 相对差 | 尺寸漂移 | 移窗漂移 | 阶数漂移 | 非平衡检查 |
|---:|---:|---:|---:|---:|---:|---:|---|
| 0 | 0.1573072 | 0.1552769 | -1.29% | 8.31% | 16.79% | 6.65% | 尺寸、移窗、阶数、第三尺寸 |
| 0.25 | 0.1619777 | 0.1981953 | 22.36% | 3.55% | 13.59% | 26.16% | 尺寸、移窗、阶数 |
| 0.5 | 0.1710592 | 0.2447443 | 43.08% | 1.84% | 18.49% | 40.68% | 移窗、阶数 |
| 0.75 | 0.1850141 | 0.2898901 | 56.69% | 1.98% | 22.13% | 50.17% | 移窗、阶数 |
| 1 | 0.2057507 | 0.3336012 | 62.14% | 1.56% | 33.98% | 55.64% | 移窗、阶数 |
| 1.25 | 0.2198317 | 0.3670684 | 66.98% | 0.63% | 22.62% | 61.56% | 移窗、阶数 |
| 1.5 | 0.2029029 | 0.3936284 | 94.00% | 0.19% | 26.15% | 74.70% | 移窗、阶数 |
| 1.75 | 0.1503602 | 0.3233235 | 115.03% | 0.07% | 25.57% | 80.47% | 移窗、阶数 |
| 2 | 0.08699324 | 0.1875755 | 115.62% | 0.04% | 39.47% | 76.58% | 移窗、阶数 |

下图同时显示系数、比值和相对差，阴影是预定模型/窗口的敏感性范围，**不是统计置信区间**。

![random_half_3系数敏感性、比值与相对差](figures_beta_patterns/random_half_3_coefficient_diagnostics.png)

[PNG](figures_beta_patterns/random_half_3_coefficient_diagnostics.png) · [PDF](figures_beta_patterns/random_half_3_coefficient_diagnostics.pdf)

代表性 β 的原始 D 与拟合如下：左图横轴为 ln L，右图为 ln θ；拟合线只画在实际使用的窗口内，包含所声明的逆尺度修正，并非强制直线。

![random_half_3 beta=0平衡与非平衡标度](figures_beta_patterns/random_half_3_scaling_beta_0.png)

[PNG](figures_beta_patterns/random_half_3_scaling_beta_0.png) · [PDF](figures_beta_patterns/random_half_3_scaling_beta_0.pdf)

![random_half_3 beta=0.5平衡与非平衡标度](figures_beta_patterns/random_half_3_scaling_beta_0p5.png)

[PNG](figures_beta_patterns/random_half_3_scaling_beta_0p5.png) · [PDF](figures_beta_patterns/random_half_3_scaling_beta_0p5.pdf)

![random_half_3 beta=1平衡与非平衡标度](figures_beta_patterns/random_half_3_scaling_beta_1.png)

[PNG](figures_beta_patterns/random_half_3_scaling_beta_1.png) · [PDF](figures_beta_patterns/random_half_3_scaling_beta_1.pdf)

![random_half_3 beta=1.5平衡与非平衡标度](figures_beta_patterns/random_half_3_scaling_beta_1p5.png)

[PNG](figures_beta_patterns/random_half_3_scaling_beta_1p5.png) · [PDF](figures_beta_patterns/random_half_3_scaling_beta_1p5.pdf)

![random_half_3 beta=2平衡与非平衡标度](figures_beta_patterns/random_half_3_scaling_beta_2.png)

[PNG](figures_beta_patterns/random_half_3_scaling_beta_2.png) · [PDF](figures_beta_patterns/random_half_3_scaling_beta_2.pdf)

## 如何使用这些结果

**能从构型初态投影到基态，不等于已经证明任意正 β 下的平衡与非平衡角系数相同。** 本轮分别展示可达性、拟合系数和时间侧稳定性；曲线接近本身不能替代稳定性检查，曲线分离也不能在修正未收敛时直接当作反例。

原始矩形及两个条带的面积加对数拟合另存于 [raw_entropy_fits.csv](analysis_beta_patterns/raw_entropy_fits.csv)。该表用于检查 D 的解释，不以原始矩形拟合值替换 D 的主估计。

已有的 [uniform A 加密结果](UNIFORM_A_DENSE.md) 可作为另一组对照；本页新增的是三个不同超胞构型的完整 β 曲线。

## 数据和复算入口

数值计算入口为 [beta_patterns_experiments.jl](beta_patterns_experiments.jl)，[串行队列](data/beta_patterns_queue.ps1) 按计划文件分阶段补齐网格，已有且核验过的相同参数点会复用。下面命令用于从已保存数据重新核验、拟合及生成本文。

- [原始主数据](data/beta_patterns_observations.csv)、[逐行来源](data/beta_patterns_observations_provenance.tsv)。
- [全部27组主系数](analysis_beta_patterns/primary_coefficients.csv)、[时间敏感性](analysis_beta_patterns/time_sensitivity.csv)、[平衡拟合](analysis_beta_patterns/equilibrium_fits.csv)。
- [共同时间网格的尺寸对比](analysis_beta_patterns/time_pair_fits.csv)、[逐尺寸时间拟合](analysis_beta_patterns/time_individual_fits.csv)。
- [计算计划](analysis_beta_patterns/plan.json)、[分析来源摘要](analysis_beta_patterns/summary.json)、[原始数据核验](analysis_beta_patterns/independent_data_validation.json)、[独立80位拟合核验](analysis_beta_patterns/independent_fit_validation.json)。

```powershell
python src/Measure/ai/validate_beta_patterns.py --stage final
python src/Measure/ai/analyze_beta_patterns.py --stage final
python src/Measure/ai/audit_beta_patterns_fits.py --stage final
python src/Measure/ai/review_beta_patterns_calibration.py
python src/Measure/ai/write_beta_patterns_report.py
```
