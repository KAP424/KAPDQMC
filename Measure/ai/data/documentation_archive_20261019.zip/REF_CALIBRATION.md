# 对照 Ref 后的改进：先排除尺寸与时间修正，再比较角系数

**时间窗口复核更新：本页统一 θ=2…6 的曲线只作早期窗口诊断，不能视为已经满足微观暂态与系统尺寸之间的尺度分离。** 全部构型的复核见 [时间尺度审计](analysis_time_scale/FINDINGS.md)；uniform A 的加密 β 与受限时间窗口更新见 [UNIFORM_A_DENSE.md](UNIFORM_A_DENSE.md)。局部检查通过并不表示进入渐近区。

**本页保留全部构型的早期窗口诊断；uniform A 的最新受限窗口结果见 [加密扫描](UNIFORM_A_DENSE.md)。** 已删除过期图集、旧拟合表和旧通过名单，保留可复算的原始观测数据。固定小尺寸上的较晚时间会出现有限尺寸弯曲，拟合可能把它吸收进对数系数；因此必须同时检查尺寸、时间窗口和修正项。

同一熵定义、同一尺寸网格、同一拟合模型下，Ref 平衡数据给出 **0.1553240603**，本代码给出 **0.1553250170**。两套计算相符；不是虚时演化或熵公式导致了先前几十个百分点的拟合差异。

全 A、β=0 的非平衡三参数拟合在 L=108、θ=2…6 给出 **0.1560302**。平衡 L=18…90 的基准为 **0.1554019**，扩展到 L=144 后为 **0.1555236**。相对这两个基准的偏差分别约 **0.40%**、**0.33%**。拟合系数独立求得，没有约束到平衡值。

**所有熵的 scaling 图直接使用 ln L 或 ln θ 作为横坐标，纵坐标保持 D 或原始熵，不取对数。** 定义

$$
x_L=\ln L,\qquad x_\theta=\ln\theta,\qquad D=cx+b+\cdots.
$$

纯对数 scaling 在这些坐标下是直线；带逆尺寸或逆时间修正的拟合曲线仍可弯曲。这里只变换绘图坐标，不重新选择拟合窗口，也不对横轴重复取对数。系数随 β 的比较图继续使用 β 横轴。

**这不意味着把所有构型、所有 β 的时间窗统一改成 2…6 就解决了问题。** 一些构型仍有明显早期修正，正 β 的全 A 也显示修正阶数依赖。下文全部呈现，并把“某个有限窗口的拟合值”“局部稳定性诊断”和“渐近角系数”分开。

## 1. Ref 与当前计算究竟哪里相同、哪里不同

Ref 中的计算是：

$$
E_A=-\ln|\det[C_A^2+(I-C_A)^2]|^2=2S_2(A).
$$

因此 Ref 的结果有两份相同费米子的倍数。本项目采用单种费米子、自然对数 Rényi-2 熵。Ref 的 A、B 区域分别与本项目的 A、B 几何一致，并取其熵差；对方向对称的全 A/B，有

$$
E_C^{\mathrm{Ref}}/2=S_2(A)-S_2(B)=D,
\qquad D=\frac{2S_2(A)+S_2(C)}3-S_2(B).
$$

一般不对称构型仍用加权 D，不能无条件把它改成未加权差。左右投影各演化一次，不意味着把单侧 ket 的 θ 再乘二；与 notebook 保存的 L=6 时间数据核对，时间坐标无需重标。

| 比较口径 | Ref，已除以 2 | 当前代码 | 判断 |
|---|---:|---:|---|
| 同 L=18,24,…72，拟合 log+常数+1/L | 0.1553240603 | 0.1553250170 | 差 9.57×10⁻⁷ |
| 共同 11 个平衡尺寸的原始 D | 与本代码最大差约 1.15×10⁻⁶ | 基准 | 与 Ref 有限收敛停止精度相容 |
| 按 notebook 旧平衡快照重算的五阶 cutoff 外推 | 0.1581185 | 使用另一估计器，不直接混比 | 旧 L≤69；保存图标签仅精确到约 0.1581 |
| notebook 保存的非平衡外推 | 约 0.155…0.165 | 对比拟合方法敏感性 | 来自不同外推模型，非误差棒 |

Ref 的直接纯 log 拟合本来也不是精确相等：保存的平衡/非平衡斜率约为 0.343/0.375（未除二）；更接近的数来自后续 cutoff 外推。当前 Ref 文件夹缺少 notebook 后半段读取的非平衡原始 CSV，所以保存图标签可以查阅，但不能声称完整重跑了那一部分。现存平衡数据、可恢复的 L=6 时间值和保存执行快照均已单独核验，见 [Ref 复现记录](analysis_ref_calibration/reference_audit_summary.json)。

值得采用的是 **先验证不同尺寸的非平衡曲线和系数收敛，再处理微观时间修正**。不能直接照搬原辅助函数的数值聚类或高阶多项式外推：前者不保证来自大 L 收敛尾部，后者对窗口和阶数敏感。

![Ref 同口径核对、原始时间曲线及有限尺寸污染](figures_ref_calibration/reference_calibration.png)

[PNG](figures_ref_calibration/reference_calibration.png) · [PDF](figures_ref_calibration/reference_calibration.pdf)

## 2. 本次实际改了什么

原 Bloch 演化、归一化及熵内核保持原样；改进的是数据覆盖和分析口径。补算仍从每个构型出发，投影后测量自身初始空位；有限 θ 没有替换成基态。每个尺寸都检查未测量无限虚时极限的基态可达性。

| 扫描 | 构型 | 尺寸 | 时间 | β |
|---|---|---|---|---|
| 共同密集网格 | 全部 12 个 | 90、108 | 2,2.5,…6,7,8 | 0、0.5、1、2 |
| 平衡扩展 | 全部 12 个 | 108、126、144 | 无限虚时极限 | 0 |
| 推迟时间的诊断 | 8 个早期诊断失败构型，加全 A 对照 | 108、144 | 补齐 4,5,…12 | 0 |

晚时间组是 one_B_2、diagonal_B_3、special_matched_a/b、full_empty_cluster3、random_half_3、general_matched_a/b，以及 uniform_A。它们按时间自身的尺寸/修正项诊断安排，不按与平衡值的接近程度安排。已有同参数数据按键复用，不重复计数。

本轮新增共同网格 **873 点**、平衡扩展 **36 点**、较晚时间诊断 **115 点**；另有 6 个数值交叉验证点。原有可比验证点的三个区域熵及 D 最大差为 7.46×10⁻¹⁴。

对固定 β，平衡首先使用原有共同尺寸范围，以免只更换 β=0 的平衡基准而造成图中不连续：

$$
D_{\mathrm{eq}}(L)=c_{\mathrm{eq}}\ln L+b+d/L.
$$

同时单列 β=0 的 L=18…144、36…144 和增加逆尺寸平方修正的结果。非平衡对每一窗口分别检查这些有效拟合形式：

$$
D_L(\theta)=c\ln\theta+b,\qquad
c\ln\theta+b+d/\theta,\qquad
c\ln\theta+b+e/\theta^2,\qquad
c\ln\theta+b+d/\theta+e/\theta^2.
$$

它们是用于检查截断误差的拟合模型，不是对所有构型已经推导出的精确渐近展开。共同诊断窗为 2…4、2…5、2…6、3…6、4…8；另外在 3…8、4…8 检查再加入逆时间三次项的阶数依赖。每个拟合至少留两个残差自由度。

统一 2…6 三参数估计用于展示方法变化；实心蓝色点仅表示该估计通过当前有限范围的检查：L90→108 的系数漂移不超过 2%，上下截断及加入逆时间平方项的漂移不超过 5%。分母使用非平衡系数自身，平衡值不参与任何检查。空心蓝点表示未稳定，不能当作物理角系数。

这些阈值是本次事后方法修订中的操作性诊断，**不是盲预注册、统计置信区间，也不保证真正的渐近误差小于 2% 或 5%**。逐 θ 的未平移 D 差另存；仅凭曲线肉眼重合仍不够，因为拟合斜率会放大很小的尺寸差。

还有一个必须明确的限制：在某一小窗口中删掉一个端点后系数稳定，并不能排除向更晚时间移动时的整体漂移。保留的 [240 个局部窗口检查](analysis_ref_calibration/calibration_candidates.csv) 和 [局部筛选结果](analysis_ref_calibration/calibration_selection.csv) 只是诊断记录，**不是最终可靠角系数名单**。例如正 β 全 A 的早期窗口可能局部通过，但修正阶数和更晚窗口仍给出不同估计；不能只挑其中接近平衡的一项。

## 3. β=0：12 个构型的改进结果与尚未解决的修正

下表完全保留统一 2…6 窗口；三/四参数相差明显时，不将其中任一值当作渐近角系数。平衡端的扩展也单列，避免掩盖它自身的有限尺寸修正。

| 构型 | 平衡 18…90 | 平衡 18…144 | 时间 L108 三参数 | 时间 L108 四参数 | 三参数有限范围检查 |
|---|---:|---:|---:|---:|---|
| uniform_A | 0.1554019 | 0.1555236 | 0.1560302 | 0.1527176 | 通过 |
| uniform_B | 0.1554019 | 0.1555236 | 0.1560302 | 0.1527176 | 通过 |
| one_B_2 | 0.1612516 | 0.1604689 | 0.1802914 | 0.1501306 | 未稳定 |
| one_B_3 | 0.1589882 | 0.1584792 | 0.1556607 | 0.1615707 | 通过 |
| two_B_3 | 0.1612684 | 0.1603935 | 0.1645069 | 0.1578835 | 通过 |
| diagonal_B_3 | 0.161759 | 0.1608675 | 0.2009818 | 0.1407648 | 未稳定 |
| special_matched_a | 0.1598321 | 0.1592121 | 0.1794259 | 0.1598753 | 未稳定 |
| special_matched_b | 0.1598955 | 0.1593398 | 0.1681915 | 0.1536438 | 未稳定 |
| full_empty_cluster3 | 0.1547541 | 0.1547818 | 0.1473063 | 0.1894071 | 未稳定 |
| random_half_3 | 0.1574134 | 0.1573072 | 0.222549 | 0.04734261 | 未稳定 |
| general_matched_a | 0.1550769 | 0.155388 | 0.1364321 | 0.1661819 | 未稳定 |
| general_matched_b | 0.1596768 | 0.1591641 | 0.2107202 | 0.1290012 | 未稳定 |

**未稳定不表示该构型的角项不同。** 部分构型在 L90/108 之间的早期窗口尺寸漂移已较小，但时间修正仍未受控；这与微观暂态尚未消失的解释相容。两个尺寸接近还不能排除共同的残余尺寸误差或模型偏差。反过来，向晚时间移动而不同步增大 L，又可能引入饱和污染。这两类误差必须分别检查。

![全部构型 β=0 的平衡、三参数与四参数对照](figures_ref_calibration/beta0_all_patterns.png)

[PNG](figures_ref_calibration/beta0_all_patterns.png) · [PDF](figures_ref_calibration/beta0_all_patterns.pdf)

## 4. 系数随 β：全部保留模型敏感性

黑线为同口径平衡系数，蓝线为 L108 的统一 2…6 三参数时间估计，橙线为同数据增加逆时间平方项后的结果。**这张总览是拟合诊断图，不是每个点都已经成为渐近角系数。**

例如 one_B_2、β=1 的统一时间估计约 0.0517267，虽然通过本次有限范围检查，仍比共同平衡拟合 0.0675369 低约 23.4%。这说明这套局部检查也不是充分条件；必须继续看较大范围的窗口趋势和修正阶数，不能把一个实心点直接称作可靠渐近系数，更不能据此宣布物理不等。

![全部 12 个构型的平衡与非平衡系数随 β 比较](figures_ref_calibration/coefficient_overview.png)

[PNG](figures_ref_calibration/coefficient_overview.png) · [PDF](figures_ref_calibration/coefficient_overview.pdf)

进一步比较四/五参数修正及邻近窗口，见下图。高阶拟合也会放大有限尺寸误差；不能因为残差更小就自动取更高阶。

![四参数和五参数时间修正的系数比较](figures_ref_calibration/hierarchy_coefficient_overview.png)

[PNG](figures_ref_calibration/hierarchy_coefficient_overview.png) · [PDF](figures_ref_calibration/hierarchy_coefficient_overview.pdf)

### 全 A 对照：为什么正 β 还需要修正阶数检查

下表不按与平衡值的差挑选模型，四种固定估计全部列出。正 β 下，这些较晚窗口的四/五参数值在已检查的尺寸、窗口和阶数之间比统一早窗三参数更稳定；但 β=0 时高阶晚窗的尺寸污染更强。**不同 β 不能机械采用同一窗口、同一截断阶数。** 五参数的 4…8 拟合只有 7 个点，其剩余自由度只有 2，仍需谨慎检查。

| β | 平衡 18…90 | 四参 3…8 | 四参 4…8 | 五参 3…8 | 五参 4…8 | 四参 3…8 尺寸漂移 |
|---:|---:|---:|---:|---:|---:|---:|
| 0 | 0.1554019 | 0.1445312 | 0.1367947 | 0.1277492 | 0.1042848 | 11.17% |
| 0.5 | 0.05813592 | 0.05937231 | 0.05926804 | 0.05934887 | 0.05830606 | 0.23% |
| 1 | 0.009311152 | 0.009508276 | 0.009498932 | 0.009523461 | 0.009367435 | 0.06% |
| 2 | 0.0001751571 | 0.0001788342 | 0.0001786752 | 0.0001791643 | 0.0001762324 | 0.04% |

这些是修正模型和窗口的敏感性范围，不是统计误差区间。其余 11 个构型同样完整检查，结果在上图及 CSV 中；不会用全 A 的表现替它们宣布一致。

## 5. 每个构型的原始 scaling 与拟合

每个构型展示 β=0、0.5、1、2，左图为 D 对 ln L，右图为 D 对 ln θ；两侧均不作纵向平移，拟合只画在实际窗口内。各 β 独立纵轴，强测量的小信号不会被压在同一刻度中。随后每张系数图另有一个比例面板，以平衡拟合系数为 1，便于看清 β 较大、绝对系数很小时的相对偏差。这个比例只用于事后比较，不参与选窗。

### 5.1 uniform_A

![uniform_A 的平衡与非平衡 scaling](figures_ref_calibration/scaling_uniform_A.png)

[PNG](figures_ref_calibration/scaling_uniform_A.png) · [PDF](figures_ref_calibration/scaling_uniform_A.pdf)

![uniform_A 的系数随 β 和模型敏感性](figures_ref_calibration/coefficients_uniform_A.png)

[PNG](figures_ref_calibration/coefficients_uniform_A.png) · [PDF](figures_ref_calibration/coefficients_uniform_A.pdf)

### 5.2 uniform_B

![uniform_B 的平衡与非平衡 scaling](figures_ref_calibration/scaling_uniform_B.png)

[PNG](figures_ref_calibration/scaling_uniform_B.png) · [PDF](figures_ref_calibration/scaling_uniform_B.pdf)

![uniform_B 的系数随 β 和模型敏感性](figures_ref_calibration/coefficients_uniform_B.png)

[PNG](figures_ref_calibration/coefficients_uniform_B.png) · [PDF](figures_ref_calibration/coefficients_uniform_B.pdf)

### 5.3 one_B_2

![one_B_2 的平衡与非平衡 scaling](figures_ref_calibration/scaling_one_B_2.png)

[PNG](figures_ref_calibration/scaling_one_B_2.png) · [PDF](figures_ref_calibration/scaling_one_B_2.pdf)

![one_B_2 的系数随 β 和模型敏感性](figures_ref_calibration/coefficients_one_B_2.png)

[PNG](figures_ref_calibration/coefficients_one_B_2.png) · [PDF](figures_ref_calibration/coefficients_one_B_2.pdf)

### 5.4 one_B_3

![one_B_3 的平衡与非平衡 scaling](figures_ref_calibration/scaling_one_B_3.png)

[PNG](figures_ref_calibration/scaling_one_B_3.png) · [PDF](figures_ref_calibration/scaling_one_B_3.pdf)

![one_B_3 的系数随 β 和模型敏感性](figures_ref_calibration/coefficients_one_B_3.png)

[PNG](figures_ref_calibration/coefficients_one_B_3.png) · [PDF](figures_ref_calibration/coefficients_one_B_3.pdf)

### 5.5 two_B_3

![two_B_3 的平衡与非平衡 scaling](figures_ref_calibration/scaling_two_B_3.png)

[PNG](figures_ref_calibration/scaling_two_B_3.png) · [PDF](figures_ref_calibration/scaling_two_B_3.pdf)

![two_B_3 的系数随 β 和模型敏感性](figures_ref_calibration/coefficients_two_B_3.png)

[PNG](figures_ref_calibration/coefficients_two_B_3.png) · [PDF](figures_ref_calibration/coefficients_two_B_3.pdf)

### 5.6 diagonal_B_3

![diagonal_B_3 的平衡与非平衡 scaling](figures_ref_calibration/scaling_diagonal_B_3.png)

[PNG](figures_ref_calibration/scaling_diagonal_B_3.png) · [PDF](figures_ref_calibration/scaling_diagonal_B_3.pdf)

![diagonal_B_3 的系数随 β 和模型敏感性](figures_ref_calibration/coefficients_diagonal_B_3.png)

[PNG](figures_ref_calibration/coefficients_diagonal_B_3.png) · [PDF](figures_ref_calibration/coefficients_diagonal_B_3.pdf)

### 5.7 special_matched_a

![special_matched_a 的平衡与非平衡 scaling](figures_ref_calibration/scaling_special_matched_a.png)

[PNG](figures_ref_calibration/scaling_special_matched_a.png) · [PDF](figures_ref_calibration/scaling_special_matched_a.pdf)

![special_matched_a 的系数随 β 和模型敏感性](figures_ref_calibration/coefficients_special_matched_a.png)

[PNG](figures_ref_calibration/coefficients_special_matched_a.png) · [PDF](figures_ref_calibration/coefficients_special_matched_a.pdf)

### 5.8 special_matched_b

![special_matched_b 的平衡与非平衡 scaling](figures_ref_calibration/scaling_special_matched_b.png)

[PNG](figures_ref_calibration/scaling_special_matched_b.png) · [PDF](figures_ref_calibration/scaling_special_matched_b.pdf)

![special_matched_b 的系数随 β 和模型敏感性](figures_ref_calibration/coefficients_special_matched_b.png)

[PNG](figures_ref_calibration/coefficients_special_matched_b.png) · [PDF](figures_ref_calibration/coefficients_special_matched_b.pdf)

### 5.9 full_empty_cluster3

![full_empty_cluster3 的平衡与非平衡 scaling](figures_ref_calibration/scaling_full_empty_cluster3.png)

[PNG](figures_ref_calibration/scaling_full_empty_cluster3.png) · [PDF](figures_ref_calibration/scaling_full_empty_cluster3.pdf)

![full_empty_cluster3 的系数随 β 和模型敏感性](figures_ref_calibration/coefficients_full_empty_cluster3.png)

[PNG](figures_ref_calibration/coefficients_full_empty_cluster3.png) · [PDF](figures_ref_calibration/coefficients_full_empty_cluster3.pdf)

### 5.10 random_half_3

![random_half_3 的平衡与非平衡 scaling](figures_ref_calibration/scaling_random_half_3.png)

[PNG](figures_ref_calibration/scaling_random_half_3.png) · [PDF](figures_ref_calibration/scaling_random_half_3.pdf)

![random_half_3 的系数随 β 和模型敏感性](figures_ref_calibration/coefficients_random_half_3.png)

[PNG](figures_ref_calibration/coefficients_random_half_3.png) · [PDF](figures_ref_calibration/coefficients_random_half_3.pdf)

### 5.11 general_matched_a

![general_matched_a 的平衡与非平衡 scaling](figures_ref_calibration/scaling_general_matched_a.png)

[PNG](figures_ref_calibration/scaling_general_matched_a.png) · [PDF](figures_ref_calibration/scaling_general_matched_a.pdf)

![general_matched_a 的系数随 β 和模型敏感性](figures_ref_calibration/coefficients_general_matched_a.png)

[PNG](figures_ref_calibration/coefficients_general_matched_a.png) · [PDF](figures_ref_calibration/coefficients_general_matched_a.pdf)

### 5.12 general_matched_b

![general_matched_b 的平衡与非平衡 scaling](figures_ref_calibration/scaling_general_matched_b.png)

[PNG](figures_ref_calibration/scaling_general_matched_b.png) · [PDF](figures_ref_calibration/scaling_general_matched_b.pdf)

![general_matched_b 的系数随 β 和模型敏感性](figures_ref_calibration/coefficients_general_matched_b.png)

[PNG](figures_ref_calibration/coefficients_general_matched_b.png) · [PDF](figures_ref_calibration/coefficients_general_matched_b.pdf)

## 6. 较晚时间补算：为什么不能只把 θ 继续加大

该批次不替换前面的共同窗口或通过标签。下表完整列出两个预定晚窗；尺寸漂移按该窗 L144 的三参数时间系数归一化。

| 构型 | 窗口 | c，L108 | c，L144 | L144 四参数 c | 三参数尺寸漂移 |
|---|---|---:|---:|---:|---:|
| uniform_A | 4-10 | 0.144314 | 0.1529917 | 0.1473895 | 5.67% |
| uniform_A | 6-12 | 0.1232799 | 0.1460371 | 0.1225049 | 15.58% |
| one_B_2 | 4-10 | 0.1491455 | 0.1615403 | 0.1514153 | 7.67% |
| one_B_2 | 6-12 | 0.1082187 | 0.149787 | 0.1090507 | 27.75% |
| diagonal_B_3 | 4-10 | 0.1549564 | 0.1657255 | 0.1549439 | 6.50% |
| diagonal_B_3 | 6-12 | 0.1025257 | 0.1545586 | 0.1154478 | 33.67% |
| special_matched_a | 4-10 | 0.1490876 | 0.1608543 | 0.148644 | 7.32% |
| special_matched_a | 6-12 | 0.1159651 | 0.148874 | 0.1112981 | 22.11% |
| special_matched_b | 4-10 | 0.1468794 | 0.1580555 | 0.1495885 | 7.07% |
| special_matched_b | 6-12 | 0.1148065 | 0.1478318 | 0.1126797 | 22.34% |
| full_empty_cluster3 | 4-10 | 0.1501628 | 0.1586929 | 0.148366 | 5.38% |
| full_empty_cluster3 | 6-12 | 0.1292275 | 0.1492369 | 0.122509 | 13.41% |
| random_half_3 | 4-10 | 0.133828 | 0.149143 | 0.1221016 | 10.27% |
| random_half_3 | 6-12 | 0.08797467 | 0.1322354 | 0.101193 | 33.47% |
| general_matched_a | 4-10 | 0.1417891 | 0.1511306 | 0.1479174 | 6.18% |
| general_matched_a | 6-12 | 0.1217063 | 0.1446667 | 0.1200708 | 15.87% |
| general_matched_b | 4-10 | 0.1491245 | 0.1625182 | 0.1360541 | 8.24% |
| general_matched_b | 6-12 | 0.1321199 | 0.1438297 | 0.1031315 | 8.14% |

![9 个 β=0 对照的晚时间尺寸与模型诊断](figures_ref_calibration/late_beta0_diagnostics.png)

[PNG](figures_ref_calibration/late_beta0_diagnostics.png) · [PDF](figures_ref_calibration/late_beta0_diagnostics.pdf)


这组数据用来判断下一步需要扩大 L，还是还需等待微观时间修正衰减。**它不能仅因 L144 比 L108 大就被自动宣布已到热力学极限。** 原有 random_half_3、β=1 的 L216 专项结果仍见 [专项报告](RANDOM_HALF3_BETA1.md)，这里 β=0 的补算没有替换它，也没有推翻原来的模型敏感性说明。

## 7. 如何判断两端系数是否一致

1. 先统一单/双份费米子、对数底数、几何、测量集合和虚时时间定义。Ref 基准已通过这一步。
2. 对每个实际时间窗比较多个 L 的未平移 D 和拟合系数。固定 L 的较晚窗不能直接代替无限系统的时间标度。
3. 在尺寸误差小的范围检查上下截断、修正阶数及向更晚窗口移动的趋势。局部删点稳定不是充分条件；拟合残差小也不是充分条件。
4. 平衡端独立扩大 L、改变截断和修正模型。完成两端各自的稳定性检查后才比较系数，不能用接近平衡值来反选时间窗。
5. 若没有同时摆脱微观暂态和有限尺寸饱和的窗口，报告“当前尚不能可靠提取”，而不是报告一个确定的不同角系数。

**全 A、β=0 的两端有限窗口拟合接近，但本页的早期窗口尚未建立渐近尺度分离。其余未稳定构型的有限窗差异不能证明渐近不等；“只要能投影到基态就必然相等”也不是已证明定理。**

## 8. 复现与可追溯数据

最终独立审计通过：3546 个合并观测点逐值一致，3440 个主/晚时间拟合、384 个删点拟合、384 个阶数拟合全部复算通过；四个输入来源的完整哈希一致，所有规定扫描网格齐全。对数系数复算最大差为 1.35×10⁻¹³。见 [正式审计回执](analysis_ref_calibration/audit_calibration_summary.json) 与 [计算及六次运行记录核验](analysis_ref_calibration/runner_audit_summary.json)。这些核验确认计算和报告一致，不替代物理渐近性判断。

- [新增计算脚本](ref_calibration_experiments.jl)：逐行保存、断点续跑、构型位编码及运行哈希；数据在 `data/ref_calibration_*.csv`，具体参数在同目录运行 TOML。
- [主分析](analyze_ref_calibration.py)、[诊断协议及修订记录](analysis_ref_calibration/protocol.json)：完整模型、窗口、来源与缺失检查。
- [全部拟合](analysis_ref_calibration/calibration_fits.csv)、[主比较](analysis_ref_calibration/calibration_comparison.csv)、[晚时间检查](analysis_ref_calibration/calibration_late_diagnostics.csv)、[四/五参数阶数检查](analysis_ref_calibration/calibration_order_diagnostics.csv)。
- [全部原始熵与来源行号](analysis_ref_calibration/calibration_points.csv)、[汇总记录](analysis_ref_calibration/calibration_summary.json)。
- [独立审计入口](audit_ref_calibration.py)：从原始来源重新构建设计矩阵，不调用主分析的拟合函数。
- [Ref 专图脚本](plot_ref_reference.py)、[全构型绘图](plot_ref_calibration.py)。所有图均有 PNG/PDF，图片不是由模型生成。

在新增扫描文件已完成的情况下重建分析和报告：

```powershell
python src/Measure/ai/analyze_ref_calibration.py --stage final --require-late
python src/Measure/ai/audit_ref_calibration.py --stage final
python src/Measure/ai/plot_ref_reference.py
python src/Measure/ai/plot_ref_calibration.py
python src/Measure/ai/write_ref_calibration_report.py
```

可复算的 [基线观测数据](data/ground_observations_baseline.csv)、新增原始数据及 Ref 文件保留。过期拟合和图集已删除；清理范围见 [清理记录](data/result_cleanup_manifest.json)。README、SCALING_GUIDE 及原图集入口均指向本页。
