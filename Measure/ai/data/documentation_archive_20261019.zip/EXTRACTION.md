# 非平衡提取方法入口

请使用 [REF_CALIBRATION.md](REF_CALIBRATION.md) 中的当前数据、对数坐标图及尺寸、窗口和修正阶数诊断。本页原先依据有限窗口给出的构型通过/失败名单、系数表和旧图已移除。

当前需要区分三件事：初态能否投影到基态；有限时间数据是否进入可用的标度区；该区间的系数是否与独立平衡估计一致。局部拟合稳定并不自动证明渐近角系数相等，未稳定的数据也不构成渐近不相等的反例。

构型图示和投影判断见 [SCALING_GUIDE.md](SCALING_GUIDE.md)；独立平衡检查见 [EQUILIBRIUM.md](EQUILIBRIUM.md)；random_half_3、β=1 的大尺寸专项见 [RANDOM_HALF3_BETA1.md](RANDOM_HALF3_BETA1.md)。原始扫描数据保留在 [data/](data/)。
