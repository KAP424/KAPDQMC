# random_half_3, beta=1: final analysis tables

All coefficients use natural logarithms and one-species Renyi-2 entropy. These deterministic fits have no statistical error bars or confidence intervals.

Main equilibrium reference: L18..216, corrected D coefficient 0.205224026.

## All registered time windows

Main model:

$$
D(\theta)=c\log\theta+b+\frac{d}{\theta}
$$

Each row uses exactly the same measured time grid at the two stated sizes. Relative error is signed; drift and curve difference are absolute. All percentages use the main equilibrium coefficient (curve difference also divides by the log time span).

| Window | Sizes | c_small | c_large | Relative eq error | Size coefficient drift | Curve difference |
|---|---:|---:|---:|---:|---:|---:|
| 2-6 | 108/144 | -0.0943767 | -0.0931937 | -145.411% | +0.576% | +0.124% |
| 4-8 | 180/216 | 0.1647426 | 0.1653432 | -19.433% | +0.293% | +0.047% |
| 6-12 | 180/216 | 0.2056541 | 0.2085182 | +1.605% | +1.396% | +0.320% |
| 8-16 | 180/216 | 0.1974051 | 0.2032945 | -0.940% | +2.870% | +0.834% |
| 10-20 | 180/216 | 0.1781852 | 0.1922401 | -6.327% | +6.849% | +1.848% |
| 12-24 | 180/216 | 0.1590007 | 0.1755591 | -14.455% | +8.068% | +2.855% |
| 16-32 | 180/216 | 0.0753046 | 0.1304175 | -36.451% | +26.855% | +7.829% |

## Equilibrium model sensitivity

All models below use L18..216. The raw-B corner coefficient is the negative of its fitted log coefficient.

| Observable | Model | Corner coefficient | Area coefficient | RMSE | Scaled condition |
|---|---|---:|---:|---:|---:|
| D | log | 0.1944055 | unavailable | 0.00265 | 13.6 |
| D | log_inv | 0.2052240 | unavailable | 0.000145 | 49.4 |
| D | log_inv2 | 0.2037217 | unavailable | 1.07e-05 | 151 |
| S_B | area_log | 0.1956086 | 0.3911470 | 0.000713 | 47.1 |
| S_B | area_log_inv | 0.2096859 | 0.3912347 | 5.33e-05 | 234 |
| S_B | area_log_inv2 | 0.2061399 | 0.3912193 | 4.98e-06 | 892 |

## Equilibrium lower-cutoff sensitivity

| L minimum | Corrected D coefficient | Independent raw-B coefficient |
|---:|---:|---:|
| 18 | 0.2052240 | 0.2096859 |
| 27 | 0.2046367 | 0.2083507 |
| 36 | 0.2043261 | 0.2075967 |
| 45 | 0.2041404 | 0.2070757 |
| 54 | 0.2040144 | 0.2067033 |
| 72 | 0.2038527 | 0.2062044 |
| 90 | 0.2037520 | 0.2058848 |

## Time-model and sampling sensitivity

Primary grids include registered theta=9,11 samples when both selected sizes have them. The sparse diagnostic removes these samples before all fits. Four-parameter fits require at least six common points. A missing fit is not evidence for or against that model.

| Window | L | Primary n | Pure log c | Primary corrected c | Original sparse corrected c | Primary four-parameter c | Sparse four-parameter c |
|---|---:|---:|---:|---:|---:|---:|---:|
| 2-6 | 144 | 5 | 0.3122441 | -0.0931937 | -0.0931937 | unavailable | unavailable |
| 4-8 | 216 | 5 | 0.1926393 | 0.1653432 | 0.1653432 | unavailable | unavailable |
| 6-12 | 216 | 7 | 0.1927636 | 0.2085182 | 0.2084083 | 0.2089188 | unavailable |
| 8-16 | 216 | 7 | 0.1960440 | 0.2032945 | 0.2030626 | 0.1855451 | unavailable |
| 10-20 | 216 | 7 | 0.1963812 | 0.1922401 | 0.1922156 | 0.1591474 | 0.1569170 |
| 12-24 | 216 | 6 | 0.1941581 | 0.1755591 | 0.1755591 | 0.1197720 | 0.1197720 |
| 16-32 | 216 | 6 | 0.1842578 | 0.1304175 | 0.1304175 | -0.0070927 | -0.0070927 |

## Intermediate-window model and size diagnostics

These two pre-registered windows are shown for the requested model check; the full seven-window results above remain part of the analysis.

| Window | Model | Sizes | c_small | c_large | Relative eq error | Size coefficient drift | RMSE | Inverse1/log span | Inverse2/log span |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|
| 6-12 | log | 180/216 | 0.1921323 | 0.1927636 | -6.072% | +0.308% | 0.000365 | 0.000 | 0.000 |
| 6-12 | log_inv | 180/216 | 0.2056541 | 0.2085182 | +1.605% | +1.396% | 1.02e-05 | 0.076 | 0.000 |
| 6-12 | log_inv2 | 180/216 | 0.2021932 | 0.2089188 | +1.800% | +3.277% | 1.01e-05 | 0.080 | 0.002 |
| 8-16 | log | 180/216 | 0.1944625 | 0.1960440 | -4.473% | +0.771% | 0.000179 | 0.000 | 0.000 |
| 8-16 | log_inv | 180/216 | 0.1974051 | 0.2032945 | -0.940% | +2.870% | 4.98e-05 | 0.036 | 0.000 |
| 8-16 | log_inv2 | 180/216 | 0.1724060 | 0.1855451 | -9.589% | +6.402% | 1.09e-05 | 0.155 | 0.099 |

## Receipt

Remaining planned finite keys: 0; remaining planned equilibrium sizes: 0.

Exact source, script, and plan hashes are recorded in summary.json. All individual coefficient, inverse-power correction, residual, and conditioning diagnostics remain in the CSV tables. No time window was selected by closeness to the equilibrium reference.
