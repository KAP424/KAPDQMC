# uniform_A 矩形二阶 Rényi 熵的半维计算

这是一种利用矩阵结构的精确改写，不是低能模截断。它使用已有演化程序产生的完整相关矩阵核，保持单种费米子、自然对数的归一化。

设矩形包含 p 个原胞，按先 A 后 B 的子晶格次序写实相关矩阵。令 J 为矩形原胞次序的反转矩阵；按 x 快、y 慢排序时，它同时反转矩形的两个坐标。uniform_A 协议满足

$$
K=C-\frac12 I=
\begin{pmatrix} Z&X\\X^T&-Z\end{pmatrix},\qquad
Z^T=Z,\quad JZJ=Z,\quad XJ=(XJ)^T.
$$

对 B 子晶格作正交变换 J，得到

$$
\widetilde K=
\begin{pmatrix}Z&Y\\Y&-Z\end{pmatrix},\qquad
Y=XJ,\qquad M=Z+iY=M^T.
$$

这个实矩阵表示复向量上的反线性映射 z 到 M 共轭 z。其平方对应 M 乘 M 的共轭；由于 M 复对称，后者等于 M 乘 M 的共轭转置。同时，实矩阵与表示乘 i 的矩阵反对易，因此本征值成正负对。于是

$$
\operatorname{spec}(\widetilde K)=\{+s_j(M),-s_j(M)\}_{j=1}^{p}.
$$

完整的二阶 Rényi 熵可改写为

$$
S_2=-\log\det\big[C^2+(I-C)^2\big]
=-2\sum_{j=1}^{p}\log\left(\frac12+2s_j(M)^2\right)
=-2\log\det\left(\frac12 I+2M^\dagger M\right).
$$

实现使用复数 HERK 构造最后的 p 维 Hermitian 矩阵，再作 Cholesky 分解。无需计算奇异值；奇异值只用于独立验证。对于有效相关矩阵，该正定矩阵的本征值在 1/2 到 1 之间。所有 p 个奇异值都保留，等价于完整 2p 维相关矩阵的全部本征值。

Dirac 零模也保留：代码直接使用现有状态的相关矩阵核，不计算有奇点的相位除法，不删除零能量点，也不改变构型初态在零模子空间内的占据。因此结果对应原有演化及测量协议选择的态。

[实现](../uniformA_entropy_extension.jl)只接受 m=1、每个原胞初始占据 A 的协议，并逐次检查实性、互补子晶格块、矩形反演结构及轨道正交性。浮点计算仅在这些检查通过后对 M 的转置反对称舍入误差作平均；虚部误差及其熵误差上界随结果返回。结构不满足时明确报错，不自动套用半维公式。

[独立验证脚本](../validate_uniformA_entropy_extension.jl)检查 L=18、36，虚时 0、4、无穷，测量强度 0、0.3、1、2，共 24 个案例。它同时比较原完整矩阵本征值算法、完整实矩阵 Cholesky、完整块变换与正负奇异值谱。最大熵差为 1.30e−12，块变换误差 1.59e−15，配对谱误差 8.00e−15；数值和源码哈希见[验证回执](half_entropy_validation.toml)与[逐案例数据](half_entropy_validation.csv)。这些是数值恒等式验证，不是统计误差条，也不用于宣称大尺寸运行速度。
