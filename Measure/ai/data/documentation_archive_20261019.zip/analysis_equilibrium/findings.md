# Equilibrium analysis numerical findings

Inputs are the completed independent equilibrium scans, totaling 1505 rows: 1005 actual-ground inputs and 500 obstructed inputs. Old observations.csv is not an analysis input and is unchanged. The source hashes and software receipt are in summary.json. Ground classification uses premeasurement energy excess, never the measured energy. All quantities are single-species Renyi-2 entropies with natural logarithms.

The reference fit window is L=18..90. Fits are unweighted deterministic least squares. Area coefficients are estimated independently in each region; the geometry relation is tested separately. The model for the raw strips is

$$
S_A=a_A L+b_A+d_A/L,\qquad S_C=a_C L+b_C+d_C/L.
$$

The raw rectangle and independent subtraction fits are

$$
S_B=a_B L-c_B\ln L+b_B+d_B/L,\qquad D=\frac{2S_A+S_C}{3}-S_B=c_D\ln L+b_D+d_D/L.
$$

The nine-parameter joint model imposes the perimeter relation while retaining separate constants and inverse-size corrections:

$$
a_B=(2a_A+a_C)/3.
$$

Free-log strip models and a free-area D model are also fitted as diagnostics. A small raw-entropy residual is not a precision estimate for the subleading logarithm. All reported c values are finite-size effective coefficients unless model and window agreement supports more. No fit-window ranges are statistical confidence intervals.

## Uniform input baseline

| beta | a_A = a_C | a_B | raw-B c | D c | joint c | D c at latest window | latest Lmin |
|---:|---:|---:|---:|---:|---:|---:|---:|
| 0 | 0.67296144 | 0.67294364 | 0.15384229 | 0.15540187 | 0.15536882 | 0.15565803 | 48 |
| 0.5 | 0.24268503 | 0.2426972 | 0.059235477 | 0.058135918 | 0.058191741 | 0.058581105 | 48 |
| 1 | 0.038097612 | 0.038099765 | 0.0095050655 | 0.0093111517 | 0.0093204335 | 0.0093767782 | 48 |
| 2 | 0.00071418598 | 0.00071422632 | 0.00017878935 | 0.00017515706 | 0.00017532988 | 0.00017635932 | 48 |

For uniform_A at beta=0, the three extraction procedures agree within about 1%; at nonzero beta raw-B c differs from D c by about 2%. The raw area terms have much smaller model disagreement. Uniform_B agrees numerically with uniform_A. This is not a demonstration that every selected configuration has the same corner coefficient.

## All actual-ground inputs: independent D fits

Each cell is the L=18..90 coefficient followed by [minimum, maximum] over supported windows with actual Lmin >= 18, at fixed Lmax=90. The tested requested cutoffs are 18, 27, 36, 45; each is aligned to the pattern grid. No values are interpolated between measurement strengths.

| pattern | beta=0 | beta=0.5 | beta=1 | beta=2 |
|---|---:|---:|---:|---:|
| `diagonal_B_3` | 0.16175895 [0.159923, 0.161759] | 0.14439994 [0.142517, 0.1444] | 0.084245422 [0.0838628, 0.0842454] | 0.003013555 [0.00301355, 0.00322926] |
| `full_empty_cluster3` | 0.15475409 [0.154753, 0.154776] | 0.16452522 [0.164525, 0.166539] | 0.12096879 [0.120969, 0.129959] | 0.0042037553 [0.00420376, 0.00502816] |
| `general_matched_a` | 0.15507686 [0.155077, 0.155751] | 0.13971605 [0.139716, 0.139893] | 0.053687324 [0.0534164, 0.0536873] | 0.0013176002 [0.00130835, 0.0013176] |
| `general_matched_b` | 0.15967683 [0.158627, 0.159677] | 0.17049067 [0.168256, 0.170491] | 0.18579991 [0.182106, 0.1858] | 0.02403089 [0.0240309, 0.0268074] |
| `one_B_2` | 0.16125158 [0.15952, 0.161252] | 0.12774536 [0.127077, 0.127745] | 0.06753688 [0.0673102, 0.0675369] | 0.0024783205 [0.00246413, 0.00247832] |
| `one_B_3` | 0.15898818 [0.15793, 0.158988] | 0.086678794 [0.0866246, 0.0866788] | 0.022381894 [0.0223819, 0.0224788] | 0.00049417897 [0.000494179, 0.000497444] |
| `random_half_3` | 0.15741338 [0.157212, 0.157413] | 0.17175037 [0.170395, 0.17175] | 0.20664834 [0.20484, 0.206648] | 0.087515645 [0.0855824, 0.0875156] |
| `special_matched_a` | 0.15983212 [0.158556, 0.159832] | 0.11662826 [0.11567, 0.116628] | 0.042503443 [0.0421855, 0.0425034] | 0.001065187 [0.00105862, 0.00106519] |
| `special_matched_b` | 0.15989553 [0.158755, 0.159896] | 0.11393441 [0.113934, 0.114097] | 0.047975435 [0.0476386, 0.0479754] | 0.0014462257 [0.00143454, 0.00144623] |
| `two_B_3` | 0.16126839 [0.159458, 0.161268] | 0.1144967 [0.114026, 0.114497] | 0.04724896 [0.047249, 0.0473502] | 0.0013959077 [0.00139591, 0.0014153] |
| `uniform_A` | 0.15540187 [0.155402, 0.155658] | 0.058135918 [0.0581359, 0.0585811] | 0.0093111517 [0.00931115, 0.00937678] | 0.00017515706 [0.000175157, 0.000176359] |
| `uniform_B` | 0.15540187 [0.155402, 0.155658] | 0.058135918 [0.0581359, 0.0585811] | 0.0093111517 [0.00931115, 0.00937678] | 0.00017515706 [0.000175157, 0.000176359] |

The largest relevant model disagreements are not resolved by this scan. At beta=1, full_empty_cluster3 gives raw-B c=0.15248659 versus D c=0.12096879; general_matched_b gives 0.13058267 versus 0.18579991. The corresponding joint fits stay close to D because they constrain the area terms; that is not independent evidence of a common thermodynamic corner term. At beta=2, full_empty_cluster3 and general_matched_b also show appreciable D window drift. D fits for obstructed inputs are not ground-state corner estimates.

## Matched-count arrangements

All four new arrangements reach ground-state energy at every sampled size. Within the special pair the A-B occupation imbalance is 5 and double/empty cell counts are 0/0. Within the general pair the imbalance is 1 and double/empty counts are 1/1. These are selected counterexamples to a counts-only description, not a survey of all arrangements.

| pattern | beta | a_A | a_C | a_B | D c, Lmin=18 | D c, Lmin=45 |
|---|---:|---:|---:|---:|---:|---:|
| `special_matched_a` | 1 | 0.11321016 | 0.11321016 | 0.1131841 | 0.042503443 | 0.042185502 |
| `special_matched_a` | 2 | 0.0025609127 | 0.0025609127 | 0.0025604272 | 0.001065187 | 0.0010586243 |
| `special_matched_b` | 1 | 0.24759486 | 0.13058841 | 0.20858437 | 0.047975435 | 0.047638613 |
| `special_matched_b` | 2 | 0.0074510859 | 0.0035702073 | 0.0061578552 | 0.0014462257 | 0.0014345358 |
| `general_matched_a` | 1 | 0.13338484 | 0.16259804 | 0.14315095 | 0.053687324 | 0.05341643 |
| `general_matched_a` | 2 | 0.0030202452 | 0.0037515561 | 0.0032642995 | 0.0013176002 | 0.0013083508 |
| `general_matched_b` | 1 | 0.53951157 | 0.52254093 | 0.53323038 | 0.18579991 | 0.18210598 |
| `general_matched_b` | 2 | 0.070229318 | 0.080596057 | 0.073686163 | 0.02403089 | 0.026807407 |

The area coefficients make the arrangement dependence and anisotropy direct. For example, the special pair at beta=1 changes from a_A=a_C=0.113210 to a_A=0.247595 and a_C=0.130588 despite identical counts. The D difference between this pair remains under every tested large-size window; it is still an effective finite-size distinction. Cut-phase averaged small-size controls are documented separately in data/equilibrium_control_findings.md.

## Free-log strip diagnostic

Here q_A and q_C come from fitting each strip to aL+q ln L+b+d/L. A nonzero effective q may absorb omitted finite-size corrections; it is not asserted to be a physical corner in a strip.

| pattern | beta | Lmin | q_A | q_C |
|---|---:|---:|---:|---:|
| `uniform_A` | 1 | 18 | -0.00037680058 | -0.00037680057 |
| `uniform_A` | 1 | 48 | -0.00014415615 | -0.00014415615 |
| `uniform_A` | 2 | 18 | -7.0032916e-06 | -7.0032904e-06 |
| `uniform_A` | 2 | 48 | -2.6017098e-06 | -2.6017224e-06 |
| `full_empty_cluster3` | 1 | 18 | -0.043331709 | -0.083120133 |
| `full_empty_cluster3` | 1 | 45 | -0.032258341 | -0.017989199 |
| `full_empty_cluster3` | 2 | 18 | -0.0027020131 | -0.010012732 |
| `full_empty_cluster3` | 2 | 45 | -0.0013937111 | -0.00099412192 |
| `general_matched_b` | 1 | 18 | 0.087333691 | 0.01765682 |
| `general_matched_b` | 1 | 45 | 0.058566371 | 0.016321338 |
| `general_matched_b` | 2 | 18 | -0.012352091 | -0.0032165224 |
| `general_matched_b` | 2 | 45 | 0.0063120647 | -0.0024835442 |

These diagnostics explain why four-parameter raw-B fits can have tiny residuals while their logarithmic coefficient differs substantially from D. The independent raw areas, free-strip log terms, D model, and joint model must be read together. The CSV files include condition numbers, fit residuals, and leave-one-size-out prediction errors, including grouped three-region holdouts for the joint model.

## Obstructed negative controls at beta=1

| pattern | pure-log effective D c | free-area D a | free-area D c | log-model LOO RMSE | free-area-model LOO RMSE |
|---|---:|---:|---:|---:|---:|
| `checker_AB` | 10.343503 | 0.11956537 | 0.070462081 | 0.42944751 | 0.0030475076 |
| `full_empty_checker` | 20.861808 | 0.2445603 | -0.15078194 | 0.92206981 | 0.28327855 |
| `full_empty_x` | 9.9576125 | 0.11105677 | 0.41562902 | 0.39984728 | 0.0037596332 |
| `stripe_AB_x` | 5.1359221 | 0.061497361 | -0.14792318 | 0.27558996 | 0.38581604 |
| `stripe_AB_y` | 5.0955334 | 0.061358395 | -0.17637197 | 0.26726235 | 0.34365611 |

These obstructed states are excluded from all ground-state fits. Their logarithmic-only D fit coefficients of roughly 5 to 21 are not credible ground-state corner coefficients. Adding an area term substantially improves checker_AB and full_empty_x held-out predictions, but the stripe controls retain poor or worsened predictive behavior: a single extra term does not establish their asymptotic scaling.

## Interpretation limits

- Ground-state energy equality allows distinct zero-mode occupations; beta=0 finite-size differences do not prove distinct thermodynamic universal coefficients.
- Raw area fits and matched-count entropy differences are well resolved over the measured sizes; the thermodynamic logarithmic coefficients of every configuration are not.
- All beta-dependent states are produced by the specified measurement of the accessible ground-state limit. They are not asserted to be ground states of the unmeasured Hamiltonian after measurement.
- The beta=8 legacy rows are audit points at one size and are not fitted.
- No large-size extrapolation beyond L=90, confidence interval, or distribution-wide classification of arrangements is inferred.
