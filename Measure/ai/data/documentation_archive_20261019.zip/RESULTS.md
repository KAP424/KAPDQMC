# 实验结果入口

三个额外可达基态构型的最新 β 扫描见 [BETA_PATTERNS.md](BETA_PATTERNS.md)：`one_B_2`、`diagonal_B_3`、`random_half_3` 各 9 个 β，共 27 组平衡/非平衡主估计，附全部 scaling 图和稳定性检查。不同状态的标记区分通过局部检查与仍未稳定的点，不把有限窗口差异直接当作渐近反例。

uniform A 最新的平衡与非平衡 scaling、受限时间窗及 β 加密曲线见 [UNIFORM_A_DENSE.md](UNIFORM_A_DENSE.md)。全部构型的早期窗口诊断与 Ref 对照见 [REF_CALIBRATION.md](REF_CALIBRATION.md)。本页原有的有限窗口系数比较和构型通过/失败名单已移除，不再作为研究结论。

原始测量数据仍保留。有限尺寸污染、早时修正或模型敏感性明显的观测是真实诊断数据，不能据此断言渐近 scaling 不存在，也不应删除为“错误数据”。

- [SCALING_GUIDE.md](SCALING_GUIDE.md)：区域几何、构型图示、基态投影判据及尚未证明的普遍命题。
- [EQUILIBRIUM.md](EQUILIBRIUM.md)：独立平衡实验、原始区域熵与面积项检查。
- [RANDOM_HALF3_BETA1.md](RANDOM_HALF3_BETA1.md)：random_half_3、β=1 扩展至 L=216 的专项结果与模型敏感性。
- [neq.md](neq.md)：任务原文。

## 方向加权的角贡献诊断量

在 L×L 周期系统中，两个尺寸分别沿原矢 a₁、a₂ 定义。A 在第二方向绕满整个系统，C 在第一方向绕满，都是无角条带；B 两个方向均不绕满，具有四个角。按原胞坐标单位计边界长度：

| 区域 | 平行 a₁ 的边界 | 平行 a₂ 的边界 |
|---|---:|---:|
| A=(L/3)×L | 0 | 2L |
| C=L×(L/3) | 2L | 0 |
| B=(L/3)×(2L/3) | 2L/3 | 4L/3 |

令两个方向单位边界的熵系数分别为 α₁、α₂，原矢长度因子也吸收到其中，则

$$
S_A^{\rm area}=2\alpha_2L,\qquad
S_C^{\rm area}=2\alpha_1L,\qquad
S_B^{\rm area}=\frac{2L}{3}\alpha_1+\frac{4L}{3}\alpha_2.
$$

因此加权量严格配平两个方向的局域边界项，不要求两方向系数相同：

$$
D=\frac{2S_A+S_C}{3}-S_B,\qquad D^{\rm area}=0.
$$

直接相减一般会留下线性项：

$$
(S_A-S_B)_{\rm area}=\frac{2L}{3}(\alpha_2-\alpha_1).
$$

若三个区域共享同样的非角对数项，它也因权重之和为零而抵消。采用有角区域的角项为负的约定，得到

$$
S_B=S_B^{\rm area}+g\ln L-c_B\ln L+\gamma_B+\cdots,
\qquad D=c_B\ln L+\gamma_D+\cdots.
$$

所以 D 对 ln L 的渐近斜率给出角系数，仍须检查形状常数和有限尺寸修正。**如果模型、态和微观切割均由两方向交换对称性对应，就有 S_A=S_C，此时 D 严格等于 S_A−S_B；并非必须使用加权式。**

三角或蜂窝晶格沿原矢截取的 B 是平行四边形，角度为两个 60°、两个 120°。若角函数只依赖夹角，总角贡献可简写为

$$
c_B=2a_2(\pi/3)+2a_2(2\pi/3),
$$

而非四个直角贡献。相关平滑边界与有角边界相减的方法见 [参考论文](https://arxiv.org/html/2404.13876v4)。
