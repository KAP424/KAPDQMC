"""Write the additional-configuration report from completed, audited outputs."""
from pathlib import Path
from datetime import datetime, timezone
import csv
import hashlib
import json

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "analysis_beta_patterns"
FIG = "figures_beta_patterns"


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def number(row, field):
    value = row.get(field, "")
    return float(value) if value != "" else None


def fmt(value):
    return "—" if value is None else f"{value:.7g}"


def pct(value):
    return "—" if value is None else f"{100*value:.2f}%"


def flag(row, field):
    return str(row.get(field, "")).lower() == "true"


def failure(row):
    if flag(row, "local_diagnostic_pass"):
        return "通过局部检查"
    reasons = []
    for field, limit, label in (("size_drift", .02, "尺寸"), ("D_difference_to_log_span", .01, "同点D差"),
                                 ("window_drift", .05, "移窗"), ("model_drift", .05, "阶数")):
        if number(row, field) is None or number(row, field) > limit:
            reasons.append(label)
    if row.get("third_size_gate", "").lower() == "false":
        reasons.append("第三尺寸")
    if any(flag(row, field) for field in ("size_sign_changed", "window_sign_changed", "model_sign_changed")):
        reasons.append("变号")
    if flag(row, "local_diagnostic_missing_checks"):
        reasons.append("检查不足")
    return "、".join(reasons) or "未通过"


def picture(stem, title):
    for extension in ("png", "pdf"):
        assert (ROOT/FIG/f"{stem}.{extension}").is_file(), stem
    return f"![{title}]({FIG}/{stem}.png)\n\n[PNG]({FIG}/{stem}.png) · [PDF]({FIG}/{stem}.pdf)\n"


def main():
    summary = json.loads((OUT/"summary.json").read_text(encoding="utf-8"))
    data_audit = json.loads((OUT/"independent_data_validation.json").read_text(encoding="utf-8"))
    fit_audit = json.loads((OUT/"independent_fit_validation.json").read_text(encoding="utf-8"))
    calibration = json.loads((OUT/"calibration_review.json").read_text(encoding="utf-8"))
    assert summary["stage"] == "final" and summary["required_grid_complete"] and summary["primary_complete"]
    assert data_audit["status"] == fit_audit["status"] == "PASS"
    assert data_audit["stage"] == fit_audit["stage"] == "final"
    assert summary["plan_sha256"] == digest(OUT/"plan.json") == data_audit["plan_sha256"]
    assert summary["script_sha256"] == digest(ROOT/"analyze_beta_patterns.py")
    for dependency in summary["dependencies"]:
        assert digest(Path(dependency["path"])) == dependency["sha256"]
    for source in summary["sources"]:
        if not source.get("missing"):
            assert digest(Path(source["path"])) == source["sha256"]
    for name, record in data_audit["outputs"].items():
        assert digest(ROOT/"data"/name) == record["sha256"]
        assert digest(ROOT/"data"/(Path(name).stem+"_provenance.tsv")) == record["ledger_sha256"]
    assert fit_audit["primary_summary_sha256"] == digest(OUT/"summary.json")
    for name, value in fit_audit["table_sha256"].items():
        assert digest(OUT/name) == value
    assert calibration["status"] == "COMPLETE_TIME_ONLY_REVIEW"
    assert calibration["actual_keys"] == calibration["required_keys"] == 198
    assert digest(Path(calibration["source"])) == calibration["source_sha256"]
    assert digest(ROOT/"review_beta_patterns_calibration.py") == calibration["script_sha256"]
    assert digest(OUT/"calibration_review.md") == calibration["markdown_sha256"]
    for name, value in calibration["table_sha256"].items():
        assert digest(OUT/name) == value
    with (OUT/"primary_coefficients.csv").open(encoding="utf-8", newline="") as stream:
        rows = list(csv.DictReader(stream))
    assert len(rows) == 27
    patterns = summary["plan"]["patterns"]
    main_data = data_audit["outputs"]["beta_patterns_observations.csv"]
    descriptions = {
        "one_B_2": "2×2 超胞，每胞单占：3 个 A、1 个 B",
        "diagonal_B_3": "3×3 超胞，每胞单占：6 个 A、3 个 B，B 沿对角线排列",
        "random_half_3": "3×3 固定一般构型：5 个 A、4 个 B，含一个双占胞和一个空胞",
    }
    text = ["# 另外三个可达基态构型：平衡与非平衡的 β 扫描\n",
            f"已完成三个构型的 β=0、0.25、…、2.0，共 **27 组平衡与非平衡系数对照**。本轮主表记录 {main_data['rows']} 个参数点，其中 {main_data['computed']} 点新计算、{main_data['reused']} 点按同一协议复用；原始值、来源和独立拟合核验均已保存。\n",
            "**下图是统一有限窗口下的拟合结果。只有通过尺寸、移窗和模型检查的非平衡点，才有较强的局部稳定性证据；未通过的点不能用来断言渐近系数不同，也不能作为 scaling 不存在的反例。**\n",
            picture("corner_coefficients_comparison", "三个构型的平衡和非平衡D的有限窗口对数系数随beta变化"),
            "蓝色粗实线及大空心圆表示平衡结果，橙色虚线及小方块表示非平衡结果；即使数值重合，两种标记仍可见，坐标没有人为错开。非平衡实心方块表示通过本页局部检查，空心方块表示仍未稳定；蓝色空心圆只区分数据系列。\n",
            "## 怎样读这次比较\n",
            "下表汇总主估计的比较范围。相对差取 (非平衡−平衡)/|平衡|；它描述当前拟合的差异，不是统计显著性。局部检查只针对有限虚时侧，平衡侧的尺寸及模型敏感性另外列在细节图中。\n",
            "| 构型 | β=0 的平衡 / 非平衡系数 | 全部 β 的相对差范围 | 非平衡局部检查通过的 β |\n|---|---:|---:|---|"]
    for name in patterns:
        block = [r for r in rows if r["pattern"] == name]
        zero = next(r for r in block if float(r["beta"]) == 0)
        gaps = [number(r, "relative_gap") for r in block]
        passes = [f"{float(r['beta']):g}" for r in block if flag(r, "local_diagnostic_pass")]
        text.append(f"| `{name}` | {fmt(number(zero,'c_eq'))} / {fmt(number(zero,'c_neq'))} | {pct(min(gaps))} 至 {pct(max(gaps))} | {'、'.join(passes) if passes else '无'} |")
    random_rows = [r for r in rows if r["pattern"] == "random_half_3"]
    peak = max(random_rows, key=lambda r: number(r, "c_eq"))
    time_peak = max(random_rows, key=lambda r: number(r, "c_neq"))
    assert not any(flag(r, "local_diagnostic_pass") for r in random_rows)
    for name in ("one_B_2", "diagonal_B_3"):
        ordered = sorted((r for r in rows if r["pattern"] == name), key=lambda r: float(r["beta"]))
        assert all(number(a, "c_eq") > number(b, "c_eq") for a, b in zip(ordered, ordered[1:]))
    ordered_random = sorted(random_rows, key=lambda r: float(r["beta"]))
    peak_index = ordered_random.index(peak)
    assert 0 < peak_index < len(ordered_random)-1
    assert all(number(a, "c_eq") < number(b, "c_eq") for a, b in zip(ordered_random[:peak_index], ordered_random[1:peak_index+1]))
    assert all(number(a, "c_eq") > number(b, "c_eq") for a, b in zip(ordered_random[peak_index:], ordered_random[peak_index+1:]))
    text += [f"\n平衡主拟合中，`one_B_2`、`diagonal_B_3` 的系数在所扫 β 点上随 β 下降；`random_half_3` 则先升后降，网格峰值为 β={float(peak['beta']):g}、c={fmt(number(peak,'c_eq'))}。这里只报告采样点的峰值，不作连续 β 的精确峰位推断。\n",
            f"`random_half_3` 的非平衡主估计在 β={float(time_peak['beta']):g} 达到网格峰值 c={fmt(number(time_peak,'c_neq'))}，但本构型的九个非平衡点均未通过局部检查。因此图中的幅度和峰位差异仍是有限窗口估计的差异，不能据此认定渐近角系数或其峰位不同。\n",
            "这里比较的是每个构型各自的平衡与非平衡曲线。改变构型也会改变弱测量的空间图案，因此不同构型在正 β 下不必具有相同系数。\n",
            "## 构型与计算协议\n",
            "| 构型 | 占据结构 | 本轮 β 点数 |\n|---|---|---:|"]
    for name in patterns:
        text.append(f"| `{name}` | {descriptions[name]} | 9 |")
    text += ["\n占据图集中保留在 [SCALING_GUIDE.md](SCALING_GUIDE.md#2-构型占据图)，不在各报告重复绘制。`random_half_3` 是固定的同一个图案，不是在每次计算时重新随机采样。图案、空位测量集合和切口原点均固定。\n",
             "各个新尺寸均重新检查无限虚时极限的能量及残差，确认这些初态可以投影到基态。这里的“平衡”沿用项目定义：先投影到基态，再施加相同 β 的弱测量；“非平衡”是在有限 θ 演化后再施加该弱测量。测量后的态并不要求仍是原哈密顿量的基态。\n",
             "采用同一个周期蜂窝晶格、半填充、单种自由费米子的自然对数 Rényi-2 熵。测量集合取各构型自身的初始空位，权重为 exp(−2β)。两个方向条带熵分别计算，未假定它们相等。几何组合与符号为：\n",
             "$$\n" + r"D=\frac{2S_2(A)+S_2(C)}{3}-S_2(B),\qquad A=(L/3)\times L,\quad C=L\times(L/3),\quad B=(L/3)\times(2L/3)." + "\n$$\n",
             "这里报告 D 的对数拟合系数。要把它进一步解释为纯粹的普适角系数，仍需面积项正确抵消、非角对数项可控，以及有限尺寸/时间修正已收敛；不能只凭高拟合优度得出该结论。沿蜂窝晶格原矢取区域时，B 在实空间有两个 60° 角和两个 120° 角。这里取四个角贡献之和，未除以角的个数；各角贡献还可能依赖两边方向、构型和 β。只有角函数仅依赖夹角时，才能进一步简写为：\n",
             "$$\n" + r"c_B=\sum_{j=1}^{4}a_{2,j},\qquad c_B=2a_2(\pi/3)+2a_2(2\pi/3)\quad\text{（角函数仅依赖夹角时）}." + "\n$$\n",
             "本轮未额外证明各个测量图案下的方向独立性，因此实际数据始终按 D 的总对数拟合系数报告。\n",
             "## 实际网格与拟合\n",
             "平衡：`one_B_2` 取 L=18、24、…、90，再加 108、126、144；两个 3×3 构型取 L=18、27、…、90，再加 108、126、144。所有尺寸均满足 L 能被 3m 整除，切口原点为 (1,1)。主拟合为：\n",
             "$$\n" + r"D_{\rm eq}(L)=c_{\rm eq}\ln L+b+\frac{d}{L}." + "\n$$\n",
             "另改变最小尺寸为 36、54，并加入逆平方修正，完整结果保存在平衡拟合表中。蓝色系数也是 L=18–144 的有限尺寸估计；非平衡局部检查通过，不能替代平衡侧的尺寸及模型稳定性检查，两端数值接近也不等于双方都已渐近收敛。\n",
             "非平衡：每个 β 均计算 L=144、180 的 θ=4、4.5、…、7；L=180 另加 θ=7.5、8，检验 5–8 移窗。β=0、1、2 进一步计算 L=180、216 的 θ=4、4.5、…、9，检验第三尺寸及 6–9 窗口。统一主拟合为 L=180、θ=4–7：\n",
             "$$\n" + r"D_{\rm neq}(\theta)=c_{\rm neq}\ln\theta+b+\frac{d}{\theta}+\frac{e}{\theta^2}." + "\n$$\n",
             "主估计和图中时间数据按 θ≥4 且 θ/L≤0.05 筛选，并在完全相同时间点上比较尺寸；CSV 中另保留未通过筛选的旧数据拟合作为诊断。θ/L≤0.05 是操作筛选，不能单独证明 θ≫微观尺度且 θ≪L；窄区域宽度 L/3 和速度因子也会影响尺度分离。θ=4–7 只跨越 1.75 倍，五参数诊断只有两个残差自由度，因此保留有限窗口解释。\n",
             "局部检查沿用 uniform A 的预设规则：系数尺寸漂移≤2%、同点 D 差/拟合对数变化≤1%、移窗及阶数漂移≤5%，且没有变号、检查项齐全。若存在第三尺寸，还要求其漂移≤2% 且递减。除 β=0、1、2 外，其余 β 只有两个尺寸的局部证据。所有窗口按时间侧稳定性检查，不以接近平衡结果作为选择标准。β=0、1、2 的独立时间侧校准详见 [三个窗口的完整比较](analysis_beta_patterns/calibration_review.md)。\n",
             "## 大尺寸时间校准的结果\n",
             "这一步只使用 L=180、216 的有限时间数据，独立于平衡系数。下表的‘通过窗口’同时检查尺寸差和修正模型；只有相邻窗口也一致，才多一层移窗稳定证据。它与后文使用 L=144、180 的统一主估计不是同一个检查，不能混用通过标记。\n",
             "| 构型 | β | 通过局部检查的窗口 | 通过的相邻窗口比较 |\n|---|---:|---|---|"]
    for r in calibration["summary"]:
        text.append(f"| `{r['pattern']}` | {float(r['beta']):g} | {'、'.join(r['local_windows']) or '无'} | {'；'.join(r['adjacent_diagnostic_pairs']) or '无'} |")
    zero_drift = {r["window"]: r["size_drift"] for r in calibration["window_diagnostics"]
                  if r["pattern"] == "random_half_3" and float(r["beta"]) == 0}
    assert zero_drift["4-7"] < zero_drift["5-8"] < zero_drift["6-9"]
    text += ["\n**增大虚时并不自动改善所有构型。** 例如 `random_half_3` 的 β=0 四参数拟合，在 L=180、216 间的系数漂移随窗口后移而增大；而部分正 β 数据的两个尺寸很接近，修正模型给出的系数却相差明显。原始 D 重合和拟合残差小，都不足以单独确认对数系数收敛。完整读数及未通过项见上述校准报告。\n",
             "## 三个构型的结果\n"]
    for name in patterns:
        block = [r for r in rows if r["pattern"] == name]
        passes = [f"{float(r['beta']):g}" for r in block if flag(r, "local_diagnostic_pass")]
        eq_sensitivity, sensitive_beta = max(
            (max(abs(number(r, bound)-number(r, "c_eq")) for bound in ("eq_range_min", "eq_range_max"))
             / abs(number(r, "c_eq")), float(r["beta"])) for r in block)
        text += [f"### {name}\n", picture(f"{name}_corner_coefficient_beta", f"{name}的系数随beta变化"),
                 f"改变平衡拟合的最小尺寸或修正阶数后，相对主系数的最大变化为 **{pct(eq_sensitivity)}**，出现在 β={sensitive_beta:g}。这是本次预定拟合间的敏感性，不是统计置信区间。\n",
                 f"当前局部检查通过的 β：**{'、'.join(passes) if passes else '无'}**。下表给出全部九个 β；相对差定义为 (非平衡−平衡)/|平衡|，不是误差条或统计显著性。\n",
                 "| β | 平衡 c | 非平衡 c | 相对差 | 尺寸漂移 | 移窗漂移 | 阶数漂移 | 非平衡检查 |\n|---:|---:|---:|---:|---:|---:|---:|---|"]
        for r in block:
            text.append(f"| {float(r['beta']):g} | {fmt(number(r,'c_eq'))} | {fmt(number(r,'c_neq'))} | {pct(number(r,'relative_gap'))} | {pct(number(r,'size_drift'))} | {pct(number(r,'window_drift'))} | {pct(number(r,'model_drift'))} | {failure(r)} |")
        text += ["\n下图同时显示系数、比值和相对差，阴影是预定模型/窗口的敏感性范围，**不是统计置信区间**。\n",
                 picture(f"{name}_coefficient_diagnostics", f"{name}系数敏感性、比值与相对差"),
                 "代表性 β 的原始 D 与拟合如下：左图横轴为 ln L，右图为 ln θ；拟合线只画在实际使用的窗口内，包含所声明的逆尺度修正，并非强制直线。\n"]
        for beta in (0, .5, 1, 1.5, 2):
            suffix = f"{beta:g}".replace(".", "p")
            text.append(picture(f"{name}_scaling_beta_{suffix}", f"{name} beta={beta:g}平衡与非平衡标度"))
    text += ["## 如何使用这些结果\n",
             "**能从构型初态投影到基态，不等于已经证明任意正 β 下的平衡与非平衡角系数相同。** 本轮分别展示可达性、拟合系数和时间侧稳定性；曲线接近本身不能替代稳定性检查，曲线分离也不能在修正未收敛时直接当作反例。\n",
             "原始矩形及两个条带的面积加对数拟合另存于 [raw_entropy_fits.csv](analysis_beta_patterns/raw_entropy_fits.csv)。该表用于检查 D 的解释，不以原始矩形拟合值替换 D 的主估计。\n",
             "已有的 [uniform A 加密结果](UNIFORM_A_DENSE.md) 可作为另一组对照；本页新增的是三个不同超胞构型的完整 β 曲线。\n",
             "## 数据和复算入口\n",
             "数值计算入口为 [beta_patterns_experiments.jl](beta_patterns_experiments.jl)，[串行队列](data/beta_patterns_queue.ps1) 按计划文件分阶段补齐网格，已有且核验过的相同参数点会复用。下面命令用于从已保存数据重新核验、拟合及生成本文。\n",
             "- [原始主数据](data/beta_patterns_observations.csv)、[逐行来源](data/beta_patterns_observations_provenance.tsv)。\n- [全部27组主系数](analysis_beta_patterns/primary_coefficients.csv)、[时间敏感性](analysis_beta_patterns/time_sensitivity.csv)、[平衡拟合](analysis_beta_patterns/equilibrium_fits.csv)。\n- [共同时间网格的尺寸对比](analysis_beta_patterns/time_pair_fits.csv)、[逐尺寸时间拟合](analysis_beta_patterns/time_individual_fits.csv)。\n- [计算计划](analysis_beta_patterns/plan.json)、[分析来源摘要](analysis_beta_patterns/summary.json)、[原始数据核验](analysis_beta_patterns/independent_data_validation.json)、[独立80位拟合核验](analysis_beta_patterns/independent_fit_validation.json)。\n",
             "```powershell\npython src/Measure/ai/validate_beta_patterns.py --stage final\npython src/Measure/ai/analyze_beta_patterns.py --stage final\npython src/Measure/ai/audit_beta_patterns_fits.py --stage final\npython src/Measure/ai/review_beta_patterns_calibration.py\npython src/Measure/ai/write_beta_patterns_report.py\n```\n"]
    content = "\n".join(text)
    path = ROOT/"BETA_PATTERNS.md"
    path.write_text(content, encoding="utf-8")
    receipt = dict(generated_utc=datetime.now(timezone.utc).isoformat(), report_sha256=digest(path),
                   summary_sha256=digest(OUT/"summary.json"), generator_sha256=digest(Path(__file__)),
                   data_audit_sha256=digest(OUT/"independent_data_validation.json"),
                   fit_audit_sha256=digest(OUT/"independent_fit_validation.json"),
                   calibration_review_sha256=digest(OUT/"calibration_review.json"))
    (OUT/"report_receipt.json").write_text(json.dumps(receipt, indent=2)+"\n", encoding="utf-8")
    print(path)


if __name__ == "__main__":
    main()
