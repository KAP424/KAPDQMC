# 平衡测量的匹配构型对照与强测量规律

这些是独立的小尺寸对照，没有修改主求解器或覆盖主熵数据。采用单种、粒子数守恒的自由费米子，所有熵均为自然对数的 Rényi-2 熵。每个构型先取自身可达的无限虚时极限，再测量其自身原初空位。

## 1. 相同数量统计不能决定测量后的熵

从完整普查中选出四个在 L=9、18 都达到全局基态能量的 3×3 构型。编码按 A(x,y)、B(x,y) 排列，x 最快，1 表示初始占据。

| 构型 | mask | 占据编码 | A−B | 双占据原胞 | 空原胞 |
|---|---:|---|---:|---:|---:|
| special_matched_a | 87449 | 100110011010101010 | 5 | 0 | 0 |
| special_matched_b | 87461 | 101001011010101010 | 5 | 0 | 0 |
| general_matched_a | 27094 | 011010111001011000 | 1 | 1 | 1 |
| general_matched_b | 54949 | 101001010110101100 | 1 | 1 | 1 |

special 对筛查了同统计量下全部 4 个平移不等价构型；general 对在两个尺寸均可达 GS 的 226 个平移不等价构型中，以固定种子 20261018 抽取 64 个。选择标准是 L=9 时，平移平均矩形熵从 β=0 到 β=1 的变化最小/最大。这是构造反例的筛查，不是对全部构型测量熵的穷举。

对每个构型计算全部 9 个原胞平移及其互补构型，取 β=0、0.5、1、2，L=9、18，共 576 行。平移平均使单一切口相位不能解释以下差异：

| L=18，β=1 | 平移平均 S_A | 平移平均 S_C | 平移平均 S_B | 平移平均 D |
|---|---:|---:|---:|---:|
| special_matched_a | 2.142397 | 2.142397 | 2.027904 | 0.114493 |
| special_matched_b | 2.818850 | 2.818850 | 2.679574 | 0.139276 |
| general_matched_a | 2.226657 | 2.647943 | 2.232275 | 0.134811 |
| general_matched_b | 8.434823 | 8.226346 | 7.796961 | 0.568370 |

因此，A/B 占据不平衡、双占据数量、special/general 标签的组合仍不足以决定有限尺寸平衡测量熵；空间排布是必要信息。这里还没有从这两个小尺寸提取渐近系数，不能直接称为不同的普适系数。各构型也可能选择不同零模，因此对照包含实际协议中的简并态选择与测量图案两个因素。

互补构型在相同区域上的熵一致，全部检查最大差为 1.33e−13。只平移构型、固定区域时，熵一般变化；将构型与区域一起平移，协变检查最大误差为 6.39e−14。

互补等熵还有本模型的解析保证。对无在位势的实数二分图 hopping，粒子—空穴变换将初始构型及自身测量目标一起取补。令 Γ 在 A/B 子格分别取 +1/−1，则两个协议的区域关联矩阵满足

$$
C_R^{\mathrm{complement}}=I_R-\Gamma_R C_R^T\Gamma_R.
$$

所以关联矩阵本征值逐个互换为 1−ν，Rényi-2 熵严格相同。这对有限虚时及可达无限虚时极限都成立，前提是构型和对应自身测量集合一起取补。

原始及汇总文件：[选择结果](arrangement_selection.csv)、[筛查记录](arrangement_screening.csv)、[576 行对照](arrangement_controls.csv)、[平移平均](arrangement_phase_averages.csv)、[平移协变](arrangement_covariance.csv)、[验证汇总](arrangement_validation.csv)。新扫描可直接 include [arrangement_patterns.jl](../arrangement_patterns.jl)，调用 `matched_arrangement_patterns()`。

## 2. 有限系统强测量的公共指数与构型相关前因子

固定有限 L，令 F 为初始满位、E 为初始空位，Q 为测量前的正交占据轨道。由于从自身初态精确演化的态与该初态非正交，方阵 Q_F 可逆。右乘可逆矩阵不会改变 Slater 占据子空间，因而测量态可写成图表示：

$$
t=e^{-2\beta},\qquad X=Q_EQ_F^{-1},\qquad
\operatorname{span}(M_EQ)=\operatorname{span}\begin{pmatrix}I\\tX\end{pmatrix}.
$$

按 F、E 排序，其归一化关联矩阵为

$$
C(t)=
\begin{pmatrix}
(I+t^2X^\dagger X)^{-1}&t(I+t^2X^\dagger X)^{-1}X^\dagger\\
tX(I+t^2X^\dagger X)^{-1}&t^2X(I+t^2X^\dagger X)^{-1}X^\dagger
\end{pmatrix}.
$$

令 R 为测量纠缠的空间区域，补区域为其余格点。强测量展开的精确领先系数是

$$
A_R=2\left(
\left\|X[E\cap R,F\cap\bar R]\right\|_F^2+
\left\|X[E\cap\bar R,F\cap R]\right\|_F^2
\right),
$$

$$
S_2(R)=A_R e^{-4\beta}+O(e^{-8\beta}),
\qquad e^{-2\beta}\|X\|_2\ll1.
$$

原因是跨区域关联矩阵的领先项为 t 倍的跨区域 X；纯态熵的领先项为跨区域关联矩阵 Frobenius 范数平方的两倍。将 t 变为负数等价于对 E 上轨道施加局域相位，熵不变，因此没有奇数次项。

对 A_R 非零的区域，公共衰减指数为 4，但前因子和进入渐近区的 β 都依赖构型、区域和 L。若 A_R=0，则 X 不跨越该划分，态对该划分完全分解，熵恒为零，不能为它定义非零衰减指数。条件可由测量前初始满位块的最小奇异值直接判断：

$$
\|X\|_2=\sqrt{\sigma_{\min}(Q_F)^{-2}-1}.
$$

这个展开不要求测量前达到全局基态，也适用于可达的受阻定态；它始终固定有限 L，不能据此交换强测量与热力学极限。

对原有 13 个构型加上上述 4 个新构型，使用最小测试尺寸：m≤2 取 L=6，m=3 取 L=9。所有态均从对应自身构型投影，计算 β=2、3、4、6、8，共 85 行。

| β | 17 种构型最大相对误差：S_B exp(4β)/A_B − 1 的绝对值 | 最大 t‖X‖ |
|---:|---:|---:|
| 2 | 0.2091 | 0.6229 |
| 3 | 0.004948 | 0.08430 |
| 4 | 9.113e−5 | 0.01141 |
| 6 | 3.058e−8 | 2.090e−4 |
| 8 | 6.578e−10 | 3.827e−6 |

所有 17 种构型都支持该展开。β=2 尚未进入所有构型共同的渐近区，不能只根据 β 的绝对大小判断“足够强”。数据：[强测量对照](strong_measurement_controls.csv)。

## 3. 极小熵的稳定计算与旧 β=8 数据的精度

对于全系统纯、粒子数守恒的 Slater 态，关联矩阵满足

$$
C^\dagger=C,\qquad C^2=C,\qquad
C_R(I-C_R)=C_{R\bar R}C_{\bar RR}.
$$

若 s_j 是跨区域关联矩阵的奇异值，则可稳定计算

$$
S_2(R)=-\sum_j\log(1-2s_j^2),
\qquad s_j\in[0,1/2].
$$

实现使用 `-sum(log1p.(-2 .* svdvals(C[R,Rbar]).^2))`。该恒等式要求全局纯态投影矩阵，不能直接用于有限温度等混合态。极小熵时，它避免将接近 0 或 1 的 C_R 本征值舍入误差直接累加成熵；但也不意味着可以突破任意小振幅下的浮点精度限制。

旧的大尺寸 β=4/8 数据采用 C_R 本征值法。39 个区域配对得到的 β 衰减斜率为 3.336–3.999，而理论渐近值是 4。这既可能含 β=4 的未消失渐近修正，也受到 β=8 极小熵的浮点误差底影响。尤其 uniform_A、L=90 的 β=8 原始 S_B 相对 β=4 外推约大 8.10 倍，但绝对值仅约 1.92e−11。**这影响极小熵的相对精度和指数提取，不影响“已接近零纠缠”的结论。** 不应把它解释为强测量指数的物理例外。

本节的 85 行小尺寸验证使用跨区域 SVD 公式，并同时保存原本征值公式供比较。旧数据的配对诊断见 [strong_measurement_previous_pairs.csv](strong_measurement_previous_pairs.csv)。

## 4. 全 A 初态的解析基准

本仓库约定的单粒子 Bloch 哈密顿量写为

$$
h(k)=\begin{pmatrix}0&f(k)\\f(k)^*&0\end{pmatrix},
\qquad f(k)=1+e^{ik_x}+e^{-ik_y}.
$$

从全 A 初态投影到负能轨道，并测量 B 子格时，对非零能量动量块有

$$
C_\beta(k)=
\begin{pmatrix}
\dfrac{1+\tanh(2\beta)}{2}&-\dfrac{f(k)/|f(k)|}{2\cosh(2\beta)}\\
-\dfrac{f(k)^*/|f(k)|}{2\cosh(2\beta)}&\dfrac{1-\tanh(2\beta)}{2}
\end{pmatrix}.
$$

非对角元相对 β=0 的振幅比正是

$$
\frac{C_{AB}(\beta,k)}{C_{AB}(0,k)}=\operatorname{sech}(2\beta).
$$

在两个 Dirac 点，初始 A 零模保持占据，不能使用上面含未定义相位的公式，而应取

$$
C_\beta(k_D)=\operatorname{diag}(1,0).
$$

所以 L 为 3 的倍数时，总空位占据为

$$
\langle N_E\rangle=(L^2-2)\frac{e^{-4\beta}}{1+e^{-4\beta}}.
$$

核验 L=6、9、12，β=0、0.5、1、2、4，共 15 个参数组，非零动量块关联矩阵最大误差 3.89e−16，总空位占据也与解析式一致。数据：[uniform_A_measurement_kernel.csv](uniform_A_measurement_kernel.csv)。

## 5. 原始熵的联合拟合关系

对 A=(L/3)×L、C=L×(L/3)、B=(L/3)×(2L/3)，一般先允许三个区域各自含对数项：

$$
S_A=a_A L+\ell_A\ln L+c_A+d_A/L+\cdots,
$$

$$
S_C=a_C L+\ell_C\ln L+c_C+d_C/L+\cdots,
$$

$$
S_B=a_B L+\ell_B\ln L+c_B+d_B/L+\cdots.
$$

局域边界项按两个方向可加，且微观切口相位匹配时，其关系为

$$
a_B=\frac{2a_A+a_C}{3}.
$$

因此平衡面积项相消组合的对数系数为

$$
D=\frac{2S_A+S_C}{3}-S_B,
\qquad c_D=\frac{2\ell_A+\ell_C}{3}-\ell_B.
$$

只有确认两个平滑条带没有对数项，才能将 D 的系数解释为矩形的总角项：

$$
\ell_A=\ell_C=0,\qquad c_D=-\ell_B=\alpha.
$$

可先独立拟合原始三条曲线，检验面积项约束与平滑条带对数项，再做约束联合拟合：

$$
S_A=a_A L+c_A+d_A/L,\qquad
S_C=a_C L+c_C+d_C/L,
$$

$$
S_B=\frac{2a_A+a_C}{3}L-\alpha\ln L+c_B+d_B/L.
$$

每条原始曲线的残差、改变最小尺寸后的参数漂移以及约束/非约束模型差异都应保留。平移平均或固定切割微观相位是必要的控制；这些模型假设不能仅靠 D 拟合良好来验证。

## 6. 复现命令

在仓库根目录运行：

```powershell
julia --startup-file=no src/Measure/ai/pattern_arrangement_controls.jl
julia --startup-file=no src/Measure/ai/strong_measurement_controls.jl
```

第一条命令读取已有穷举 CSV、重新筛查代表并计算 L=9/18 对照；若只重建平移平均汇总，可加 `--summarize-only`。第二条仅计算上述小尺寸强测量与解析核验，并读取主 observations.csv 中已有 β=4/8 行，不重跑大尺寸。两条命令固定使用一个 BLAS 线程。
