# 基态可达构型 scaling 图集入口

全部 12 个已扫描的基态可达构型，其当前平衡/非平衡 scaling 图、系数随 β 的比较及修正模型诊断，统一见 [REF_CALIBRATION.md](REF_CALIBRATION.md)。

本页原先固定小尺寸和晚时间窗口的图集、系数表及相关结论已移除。原始熵观测保留；撤下的是将未经充分尺寸与修正检查的有限窗口系数当作渐近结果的展示方式。

- 构型占据图和基态可达性：[SCALING_GUIDE.md](SCALING_GUIDE.md)。
- 独立平衡实验：[EQUILIBRIUM.md](EQUILIBRIUM.md)。
- random_half_3、β=1 扩展至 L=216 的专项：[RANDOM_HALF3_BETA1.md](RANDOM_HALF3_BETA1.md)。
