# 一般实相关矩阵的复移位行列式算法

本扩展只改变矩形熵的数值计算方式，保留传入状态的全部自由度，不改变演化、测量或初态。它不使用 uniform A 的子晶格半维结构。

对 n 维 Hermitian 相关矩阵，定义

$$
z=\frac{1+i}{2},\qquad A=C-zI.
$$

因为两因子都是 C 的多项式，且彼此对易，

$$
C^2+(I-C)^2=2(C-zI)(C-\bar zI)=2AA^\dagger.
$$

因此单种费米子的自然对数二阶 Rényi 熵精确满足

$$
S_2=-n\ln2-2\ln|\det A|.
$$

实现使用 `logabsdet`，没有复对数分支选择问题。对有效相关矩阵，移位矩阵的奇异值介于 1/2 与 1/√2，条件数至多 √2。该公式保留所有本征值，包括 Dirac 零模所贡献的实际占据；不存在低模截断或将有限虚时替换为基态的步骤。

当 C 为实对称矩阵时，A 为复对称矩阵，可采用复对称 Bunch–Kaufman、rook-pivot Bunch–Kaufman 或一般 LU 分解。当前扩展只使用经过实性、Hermitian 性及轨道正交检查的这个分支；舍入虚部的控制与原实矩阵熵扩展相同。算法始终处理完整 n 维矩形矩阵。

省去矩阵平方不保证更快：原算法使用高效的实数 SYRK 加 Cholesky，新方法则进行完整尺寸的复数分解。速度判断以包含相关核重建、矩阵构造与分解的顺序实测为准；不能仅比较理论上的分解步骤数。

- [可选实现](../multi_pattern_entropy_extension.jl)
- [小尺寸验证](../validate_multi_pattern_entropy_extension.jl)：96 个物理案例、3 种方法，以及 96 个已知谱和复制数检查；对照完整本征值法和实 Cholesky。
- [逐案例数据](small_validation.csv)、[验证回执](small_validation.toml)、[小尺寸预热计时](small_warm_timings.csv)。
- [单个代表性尺寸基准](../benchmark_multi_pattern_entropy_extension.jl)：顺序执行、每次释放内存、8 个 BLAS 线程，计时包含矩形相关矩阵重建和分解；不包括各方法共用的状态准备和演化。

代表性测试使用 random_half_3、L=108、虚时 5、测量强度 1，完整矩形维数 5184。首轮作为该尺寸的预热，后两轮交换执行顺序；包含相关核、矩阵构造及分解的时间中值如下。

| 方法 | 时间（秒） | 相对原实 Cholesky |
|---|---:|---:|
| 原实 Cholesky | 1.12054 | 1.00 |
| 复 LU | 1.82668 | 1.63 |
| 复对称 Bunch–Kaufman | 2.22159 | 1.98 |
| 复对称 rook Bunch–Kaufman | 2.15641 | 1.92 |

所有新算法与原实 Cholesky 的熵差不超过 3.12e−12，但该代表性尺寸没有加速。因此正式扫描继续使用原实 Cholesky；新扩展仅作为独立的精确算法验证保留。详见[计时数据](representative_benchmark.csv)及[来源和方法回执](representative_benchmark.toml)。这不是对所有尺寸和硬件的性能定理。

统计残差、模型敏感性和性能测试误差都不应混为物理系数的置信区间。
